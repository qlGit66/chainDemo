package com.qll.chaindemo.service;

import com.qll.chaindemo.domain.HospitalInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 86182
* @description 针对表【hospital_info(普通医院信息表)】的数据库操作Service
* @createDate 2024-10-24 21:33:15
*/
public interface HospitalInfoService extends IService<HospitalInfo> {

}
