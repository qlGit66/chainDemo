package com.qll.chaindemo.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;

import com.qll.chaindemo.common.classes.HospitalRequest;
import com.qll.chaindemo.interfaces.HospitalHandler;
import lombok.Data;

/**
 * PCI医院信息表
 * @TableName pci
 */
@TableName(value ="pci")
@Data
public class Pci implements Serializable , HospitalHandler {
    /**
     * 主键
     */
    @TableId
    private Long pciId;

    /**
     * 地理位置
     */
    private String pciLocation;

    /**
     * GPS位置-经度
     */
    private Double pciGpsLongitude;

    /**
     * GPS位置-纬度
     */
    private Double pciGpsLatitude;

    /**
     * 负责人联系电话
     */
    private String pciContact;

    /**
     * PCI医院全称
     */
    private String pciName;

    /**
     * PCI医院简称
     */
    private String pciNameOmitted;

    /**
     * PCI医院简介（120字）
     */
    private String pciIntroduction;

    /**
     * 主治医生数量，根据下属的注册医生数量确定
     */
    private Integer pciDoctorNumber;

    /**
     * 可以做胸痛手术的手术室数量，注册的时候用户填
     */
    private Integer pciOperatingNumber;

    /**
     * open_id，允许null
     */
    private String pciOpenId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 创建者
     */
    private Long createUsr;

    /**
     * 修改者
     */
    private Long modifyUsr;

    /**
     * 逻辑删除
     */
    private Integer isdeleted;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;


    @Override
    public AmbulancesInfo handleRequest(HospitalRequest request) {

        return null;
    }

    @Override
    public void setNextHandler(HospitalHandler nextHandler) {
        this.setNextHandler(nextHandler);
    }
    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Pci other = (Pci) that;
        return (this.getPciId() == null ? other.getPciId() == null : this.getPciId().equals(other.getPciId()))
            && (this.getPciLocation() == null ? other.getPciLocation() == null : this.getPciLocation().equals(other.getPciLocation()))
            && (this.getPciGpsLongitude() == null ? other.getPciGpsLongitude() == null : this.getPciGpsLongitude().equals(other.getPciGpsLongitude()))
            && (this.getPciGpsLatitude() == null ? other.getPciGpsLatitude() == null : this.getPciGpsLatitude().equals(other.getPciGpsLatitude()))
            && (this.getPciContact() == null ? other.getPciContact() == null : this.getPciContact().equals(other.getPciContact()))
            && (this.getPciName() == null ? other.getPciName() == null : this.getPciName().equals(other.getPciName()))
            && (this.getPciNameOmitted() == null ? other.getPciNameOmitted() == null : this.getPciNameOmitted().equals(other.getPciNameOmitted()))
            && (this.getPciIntroduction() == null ? other.getPciIntroduction() == null : this.getPciIntroduction().equals(other.getPciIntroduction()))
            && (this.getPciDoctorNumber() == null ? other.getPciDoctorNumber() == null : this.getPciDoctorNumber().equals(other.getPciDoctorNumber()))
            && (this.getPciOperatingNumber() == null ? other.getPciOperatingNumber() == null : this.getPciOperatingNumber().equals(other.getPciOperatingNumber()))
            && (this.getPciOpenId() == null ? other.getPciOpenId() == null : this.getPciOpenId().equals(other.getPciOpenId()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getModifyTime() == null ? other.getModifyTime() == null : this.getModifyTime().equals(other.getModifyTime()))
            && (this.getCreateUsr() == null ? other.getCreateUsr() == null : this.getCreateUsr().equals(other.getCreateUsr()))
            && (this.getModifyUsr() == null ? other.getModifyUsr() == null : this.getModifyUsr().equals(other.getModifyUsr()))
            && (this.getIsdeleted() == null ? other.getIsdeleted() == null : this.getIsdeleted().equals(other.getIsdeleted()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getPciId() == null) ? 0 : getPciId().hashCode());
        result = prime * result + ((getPciLocation() == null) ? 0 : getPciLocation().hashCode());
        result = prime * result + ((getPciGpsLongitude() == null) ? 0 : getPciGpsLongitude().hashCode());
        result = prime * result + ((getPciGpsLatitude() == null) ? 0 : getPciGpsLatitude().hashCode());
        result = prime * result + ((getPciContact() == null) ? 0 : getPciContact().hashCode());
        result = prime * result + ((getPciName() == null) ? 0 : getPciName().hashCode());
        result = prime * result + ((getPciNameOmitted() == null) ? 0 : getPciNameOmitted().hashCode());
        result = prime * result + ((getPciIntroduction() == null) ? 0 : getPciIntroduction().hashCode());
        result = prime * result + ((getPciDoctorNumber() == null) ? 0 : getPciDoctorNumber().hashCode());
        result = prime * result + ((getPciOperatingNumber() == null) ? 0 : getPciOperatingNumber().hashCode());
        result = prime * result + ((getPciOpenId() == null) ? 0 : getPciOpenId().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getModifyTime() == null) ? 0 : getModifyTime().hashCode());
        result = prime * result + ((getCreateUsr() == null) ? 0 : getCreateUsr().hashCode());
        result = prime * result + ((getModifyUsr() == null) ? 0 : getModifyUsr().hashCode());
        result = prime * result + ((getIsdeleted() == null) ? 0 : getIsdeleted().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", pciId=").append(pciId);
        sb.append(", pciLocation=").append(pciLocation);
        sb.append(", pciGpsLongitude=").append(pciGpsLongitude);
        sb.append(", pciGpsLatitude=").append(pciGpsLatitude);
        sb.append(", pciContact=").append(pciContact);
        sb.append(", pciName=").append(pciName);
        sb.append(", pciNameOmitted=").append(pciNameOmitted);
        sb.append(", pciIntroduction=").append(pciIntroduction);
        sb.append(", pciDoctorNumber=").append(pciDoctorNumber);
        sb.append(", pciOperatingNumber=").append(pciOperatingNumber);
        sb.append(", pciOpenId=").append(pciOpenId);
        sb.append(", createTime=").append(createTime);
        sb.append(", modifyTime=").append(modifyTime);
        sb.append(", createUsr=").append(createUsr);
        sb.append(", modifyUsr=").append(modifyUsr);
        sb.append(", isdeleted=").append(isdeleted);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}