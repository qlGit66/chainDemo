package com.qll.chaindemo.handerler;

import com.qll.chaindemo.common.classes.HospitalRequest;
import com.qll.chaindemo.common.enums.MessageEnum;
import com.qll.chaindemo.domain.AmbulancesInfo;
import com.qll.chaindemo.domain.NodeChainLog;
import com.qll.chaindemo.interfaces.HospitalHandler;
import com.qll.chaindemo.service.HealthRecordsService;
import com.qll.chaindemo.service.NodeChainLogService;
import com.qll.chaindemo.service.PciService;
import com.qll.chaindemo.service.intelligentSystem;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Slf4j
@Component
@Scope("prototype")
public class baseHospitalHandler implements HospitalHandler {

    private HospitalHandler nextHandler;

    private HospitalRequest request;
    @Resource
    private NodeChainLogService nodeChainLogService;
   @Resource
   private PciService pciService;
   @Resource
   private intelligentSystem intelligentSystem;
   @Resource
   private HealthRecordsService healthRecordsService;
   @Resource
   private cpcHanderler cpcHanderler;
    @Override
    public void setNextHandler(HospitalHandler nextHandler) {
             this.nextHandler = nextHandler;
    }

    @Override
    public AmbulancesInfo  handleRequest(HospitalRequest request) {
        log.info("1.先传入健康档案");
             healthRecordsService.updateRecords(request.getHealthRecords());
            log.info("2.由溶栓智能辅助诊断系统给出诊断结论，辅助医生先判断");
            log.info("医院节点结束，转到cpc也是救护车");
            String result =   intelligentSystem.getAdvice(request.getHealthRecords());
        NodeChainLog nodeChainLog = NodeChainLog.builder().id(request.getNodeId())
                .status(1).endTime(LocalDateTime.now()).build();
        nodeChainLogService.addNodeChainLog(nodeChainLog);
        request.setMessage(MessageEnum.HOSPITAL_PATIENT_PCI.getMess());
        request.setNodeId(null);
        //开始呼叫120和pci 责任链转到cpc

        this.nextHandler = cpcHanderler;
        log.info("有智能辅助系统做出进一步判断");

        return        cpcHanderler.handleRequest(request);
    }
    }

