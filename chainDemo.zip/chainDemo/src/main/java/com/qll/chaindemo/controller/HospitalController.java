package com.qll.chaindemo.controller;

import com.qll.chaindemo.common.classes.HospitalRequest;
import com.qll.chaindemo.common.classes.Result;

import com.qll.chaindemo.common.enums.MessageEnum;
import com.qll.chaindemo.common.enums.ResultCodeEnum;
import com.qll.chaindemo.domain.*;
import com.qll.chaindemo.handerler.baseHospitalHandler;
import com.qll.chaindemo.service.CpcInfoService;
import com.qll.chaindemo.service.HealthRecordsService;
import com.qll.chaindemo.service.NodeChainLogService;
import com.qll.chaindemo.service.ResponsibilityChainLogService;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author 86182
 */
@RestController
@Slf4j
@RequestMapping("/hospital")
public class HospitalController {

    @Resource
    private CpcInfoService cpcInfoService;

    @Resource
    private ResponsibilityChainLogService responsibilityChainLog;

    @Resource
    private NodeChainLogService nodeChainLog;
    @Resource
    private baseHospitalHandler baseHospitalHandler;
    //医院开始 运输链
    @GetMapping("/start/{id}")
    public Result start(@PathVariable long id ){
        HospitalInfo hospitalInfo = new HospitalInfo();
        HealthRecords healthRecords = new HealthRecords();



        log.info("开始填加新责任链");
       long chainID =    responsibilityChainLog.addResponsibilityChainLog(new ResponsibilityChainLog());
       log.info("记录第一个节点");
       //添加第一个责任节点
        NodeChainLog chainLog =    nodeChainLog.generate(chainID,hospitalInfo.getHstptNameOmitted(),hospitalInfo.getHstptId()
               ,LocalDateTime.now(),0,LocalDateTime.now(),hospitalInfo.getHstptId(),LocalDateTime.now(),hospitalInfo.getHstptId());

      long nodeId =   nodeChainLog.addNodeChainLog(chainLog);

        HospitalRequest request = HospitalRequest.builder()
                .healthRecords(healthRecords)
                .chainId(chainID)
                .message(MessageEnum.HOSPITAL_PATIENT_HOSPITAL.getMess())
                .nodeId(nodeId)
                .build();
        log.info("开始运输链");

        //返回救护车信息
      AmbulancesInfo ambulancesInfo =    baseHospitalHandler.handleRequest(request);
         return Result.success(ambulancesInfo);
    }


}
