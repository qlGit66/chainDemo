package com.qll.chaindemo.service;

import com.qll.chaindemo.domain.HealthRecords;

public interface intelligentSystem {
    String getAdvice(HealthRecords healthRecords);
}
