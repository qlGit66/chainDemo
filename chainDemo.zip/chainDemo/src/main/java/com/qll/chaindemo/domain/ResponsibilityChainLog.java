package com.qll.chaindemo.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * 责任链处理记录表
 * @TableName responsibility_chain_log
 */
@TableName(value ="responsibility_chain_log")
@Data
@Builder
@AllArgsConstructor
public class ResponsibilityChainLog implements Serializable {
    /**
     * 个人认为自增表示医院的所有病例顺序
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 尽量别外建太影响性能
     */
    private Long patientId;

    /**
     * 也就是120被打电话的时候
     */
    private LocalDateTime waitAmbulanceStarttime;

    /**
     * 救护车ID
     */
    private Long ambulanceId;

    /**
     * 救护车到达时间
     */
    private LocalDateTime waitAmbulanceEndtime;

    /**
     * 开始运送病人的时间
     */
    private LocalDateTime startTrialTime;

    /**
     * 实际运送医院
     */
    private Long actualHospitalId;

    /**
     * 到达医院时间
     */
    private LocalDateTime endArrivalTime;

    /**
     * 总时长
     */
    private LocalDateTime totalDuration;

    /**
     * 
     */
    private LocalDateTime createTime;

    /**
     * 
     */
    private LocalDateTime modifyTime;

    /**
     * 
     */
    private Long createUsr;

    /**
     * 
     */
    private Long modifyUsr;

    /**
     * 
     */
    private Integer isdeleted;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;


    public ResponsibilityChainLog() {
        this.createTime = LocalDateTime.now();
        this.modifyTime = LocalDateTime.now();
        this.createUsr = 1L;
        this.modifyUsr = 1L;
    }
}