package com.qll.chaindemo.service;

import com.qll.chaindemo.domain.AmbulancesInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 86182
* @description 针对表【ambulances_info(救护车信息表)】的数据库操作Service
* @createDate 2024-10-24 21:33:30
*/
public interface AmbulancesInfoService  {

    AmbulancesInfo findLeisureAmbulance();
}
