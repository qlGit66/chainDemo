package com.qll.chaindemo.service;

import com.qll.chaindemo.common.classes.HospitalRequest;
import com.qll.chaindemo.domain.AmbulancesInfo;
import com.qll.chaindemo.domain.Pci;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.HashMap;

/**
* @author 86182
* @description 针对表【pci(PCI医院信息表)】的数据库操作Service
* @createDate 2024-10-24 21:32:33
*/
public interface PciService  {

    AmbulancesInfo findAmbulance();

    HashMap<String, String> getRequest(HospitalRequest request);









}
