package com.qll.chaindemo.mapper;

import com.qll.chaindemo.domain.HospitalInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
* @author 86182
* @description 针对表【hospital_info(普通医院信息表)】的数据库操作Mapper
* @createDate 2024-10-24 21:33:15
* @Entity generator.domain.HospitalInfo
*/
@Mapper
public interface HospitalInfoMapper extends BaseMapper<HospitalInfo> {

}




