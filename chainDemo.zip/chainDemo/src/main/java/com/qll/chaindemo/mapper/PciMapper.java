package com.qll.chaindemo.mapper;

import com.qll.chaindemo.domain.Pci;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
* @author 86182
* @description 针对表【pci(PCI医院信息表)】的数据库操作Mapper
* @createDate 2024-10-24 21:32:33
* @Entity generator.domain.Pci
*/
@Mapper
public interface PciMapper extends BaseMapper<Pci> {

}




