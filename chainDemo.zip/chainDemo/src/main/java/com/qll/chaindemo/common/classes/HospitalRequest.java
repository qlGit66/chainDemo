package com.qll.chaindemo.common.classes;

import com.qll.chaindemo.domain.AmbulancesInfo;
import com.qll.chaindemo.domain.HealthRecords;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author ql66
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HospitalRequest {
    //0 没完成，1 完成
    private int status;
    // 其他必要字段
    private String message;
    private HealthRecords healthRecords;
    private long chainId;
    private AmbulancesInfo ambulancesInfo;
    //节点id
    private  Long  nodeId;
}
