package com.qll.chaindemo.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * 救护车信息表
 * @TableName ambulances_info
 */
@TableName(value ="ambulances_info")
@Data
public class AmbulancesInfo implements Serializable {
    /**
     * 救护车id
     */
    @TableId
    private Long ambulanceId;



    /**
     * 车牌号，待定
     */
    private String carId;

    /**
     * 微信小程序openid
     */
    private String openId;

    /**
     * 状态
     */
    private Integer status;

    /**
     * 位置gps，待定
     */
    private String location;

    /**
     * 任务id，雪花算法
     */
    private Long taskId;

    /**
     * 负责人手机号
     */
    private String telphoneNumber;

    /**
     * 负责人姓名
     */
    private String chargeName;

    /**
     * 备用手机号
     */
    private String telphoneNumberBackup;

    /**
     * 所属单位主键
     */
    private Long belongingId;

    /**
     * 所属单位名称（全称）
     */
    private String belongingName;

    /**
     * 所属PCI医院主键
     */
    private Long pciBelongingId;

    /**
     * 所属PCI医院名称
     */
    private String pciBelongingName;

    /**
     * 是否支持摄像头，0不是1是
     */
    private Integer ifCamera;

    /**
     * 是否支持心电图，0不是1是
     */
    private Integer ifEcg;

    /**
     * GPS丢包数，要显示在小程序上，点击页面上的更新位置按钮，发送最新位置，超过5个时响铃
     */
    private Integer gpsMissingNumber;

    /**
     * 下线时间
     */
    private Date offlineTime;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 创建者
     */
    private Long createUsr;

    /**
     * 修改者
     */
    private Long modifyUsr;

    /**
     * 逻辑删除
     */
    private Integer isdeleted;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AmbulancesInfo other = (AmbulancesInfo) that;
        return (this.getAmbulanceId() == null ? other.getAmbulanceId() == null : this.getAmbulanceId().equals(other.getAmbulanceId()))
            && (this.getCarId() == null ? other.getCarId() == null : this.getCarId().equals(other.getCarId()))
            && (this.getOpenId() == null ? other.getOpenId() == null : this.getOpenId().equals(other.getOpenId()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getLocation() == null ? other.getLocation() == null : this.getLocation().equals(other.getLocation()))
            && (this.getTaskId() == null ? other.getTaskId() == null : this.getTaskId().equals(other.getTaskId()))
            && (this.getTelphoneNumber() == null ? other.getTelphoneNumber() == null : this.getTelphoneNumber().equals(other.getTelphoneNumber()))
            && (this.getChargeName() == null ? other.getChargeName() == null : this.getChargeName().equals(other.getChargeName()))
            && (this.getTelphoneNumberBackup() == null ? other.getTelphoneNumberBackup() == null : this.getTelphoneNumberBackup().equals(other.getTelphoneNumberBackup()))
            && (this.getBelongingId() == null ? other.getBelongingId() == null : this.getBelongingId().equals(other.getBelongingId()))
            && (this.getBelongingName() == null ? other.getBelongingName() == null : this.getBelongingName().equals(other.getBelongingName()))
            && (this.getPciBelongingId() == null ? other.getPciBelongingId() == null : this.getPciBelongingId().equals(other.getPciBelongingId()))
            && (this.getPciBelongingName() == null ? other.getPciBelongingName() == null : this.getPciBelongingName().equals(other.getPciBelongingName()))
            && (this.getIfCamera() == null ? other.getIfCamera() == null : this.getIfCamera().equals(other.getIfCamera()))
            && (this.getIfEcg() == null ? other.getIfEcg() == null : this.getIfEcg().equals(other.getIfEcg()))
            && (this.getGpsMissingNumber() == null ? other.getGpsMissingNumber() == null : this.getGpsMissingNumber().equals(other.getGpsMissingNumber()))
            && (this.getOfflineTime() == null ? other.getOfflineTime() == null : this.getOfflineTime().equals(other.getOfflineTime()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getModifyTime() == null ? other.getModifyTime() == null : this.getModifyTime().equals(other.getModifyTime()))
            && (this.getCreateUsr() == null ? other.getCreateUsr() == null : this.getCreateUsr().equals(other.getCreateUsr()))
            && (this.getModifyUsr() == null ? other.getModifyUsr() == null : this.getModifyUsr().equals(other.getModifyUsr()))
            && (this.getIsdeleted() == null ? other.getIsdeleted() == null : this.getIsdeleted().equals(other.getIsdeleted()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getAmbulanceId() == null) ? 0 : getAmbulanceId().hashCode());
        result = prime * result + ((getCarId() == null) ? 0 : getCarId().hashCode());
        result = prime * result + ((getOpenId() == null) ? 0 : getOpenId().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getLocation() == null) ? 0 : getLocation().hashCode());
        result = prime * result + ((getTaskId() == null) ? 0 : getTaskId().hashCode());
        result = prime * result + ((getTelphoneNumber() == null) ? 0 : getTelphoneNumber().hashCode());
        result = prime * result + ((getChargeName() == null) ? 0 : getChargeName().hashCode());
        result = prime * result + ((getTelphoneNumberBackup() == null) ? 0 : getTelphoneNumberBackup().hashCode());
        result = prime * result + ((getBelongingId() == null) ? 0 : getBelongingId().hashCode());
        result = prime * result + ((getBelongingName() == null) ? 0 : getBelongingName().hashCode());
        result = prime * result + ((getPciBelongingId() == null) ? 0 : getPciBelongingId().hashCode());
        result = prime * result + ((getPciBelongingName() == null) ? 0 : getPciBelongingName().hashCode());
        result = prime * result + ((getIfCamera() == null) ? 0 : getIfCamera().hashCode());
        result = prime * result + ((getIfEcg() == null) ? 0 : getIfEcg().hashCode());
        result = prime * result + ((getGpsMissingNumber() == null) ? 0 : getGpsMissingNumber().hashCode());
        result = prime * result + ((getOfflineTime() == null) ? 0 : getOfflineTime().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getModifyTime() == null) ? 0 : getModifyTime().hashCode());
        result = prime * result + ((getCreateUsr() == null) ? 0 : getCreateUsr().hashCode());
        result = prime * result + ((getModifyUsr() == null) ? 0 : getModifyUsr().hashCode());
        result = prime * result + ((getIsdeleted() == null) ? 0 : getIsdeleted().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", ambulanceId=").append(ambulanceId);
        sb.append(", carId=").append(carId);
        sb.append(", openId=").append(openId);
        sb.append(", status=").append(status);
        sb.append(", location=").append(location);
        sb.append(", taskId=").append(taskId);
        sb.append(", telphoneNumber=").append(telphoneNumber);
        sb.append(", chargeName=").append(chargeName);
        sb.append(", telphoneNumberBackup=").append(telphoneNumberBackup);
        sb.append(", belongingId=").append(belongingId);
        sb.append(", belongingName=").append(belongingName);
        sb.append(", pciBelongingId=").append(pciBelongingId);
        sb.append(", pciBelongingName=").append(pciBelongingName);
        sb.append(", ifCamera=").append(ifCamera);
        sb.append(", ifEcg=").append(ifEcg);
        sb.append(", gpsMissingNumber=").append(gpsMissingNumber);
        sb.append(", offlineTime=").append(offlineTime);
        sb.append(", createTime=").append(createTime);
        sb.append(", modifyTime=").append(modifyTime);
        sb.append(", createUsr=").append(createUsr);
        sb.append(", modifyUsr=").append(modifyUsr);
        sb.append(", isdeleted=").append(isdeleted);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}