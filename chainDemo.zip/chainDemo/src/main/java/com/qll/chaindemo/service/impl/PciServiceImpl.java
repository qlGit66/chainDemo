package com.qll.chaindemo.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.qll.chaindemo.common.classes.HospitalRequest;
import com.qll.chaindemo.domain.AmbulancesInfo;
import com.qll.chaindemo.domain.Pci;
import com.qll.chaindemo.service.AmbulancesInfoService;
import com.qll.chaindemo.service.DoctorInfoService;
import com.qll.chaindemo.service.PciService;
import com.qll.chaindemo.mapper.PciMapper;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashMap;

/**
* @author 86182
* @description 针对表【pci(PCI医院信息表)】的数据库操作Service实现
* @createDate 2024-10-24 21:32:33
*/
@Slf4j
@Service
public class PciServiceImpl implements PciService{
@Resource
    private AmbulancesInfoService ambulancesInfoService;
 @Resource
 private DoctorInfoService doctorInfoService;
    @Override
    public AmbulancesInfo findAmbulance() {
        log.info("PCi调度中心开始寻找救护车");
      return   ambulancesInfoService.findLeisureAmbulance();
    }


    @Override
    public HashMap<String, String> getRequest(HospitalRequest request) {
      return doctorInfoService.selectPatientAnd120(request);
    }
}




