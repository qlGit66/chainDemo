package com.qll.chaindemo.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 审核员信息表
 * @TableName auditor_info
 */
@TableName(value ="auditor_info")
@Data
public class AuditorInfo implements Serializable {
    /**
     * 审核员主键，雪花算法
     */
    @TableId
    private Long auditorId;

    /**
     * 审核员姓名，数据库内加密
     */
    private String auditorName;

    /**
     * 审核员手机号，数据库内加密
     */
    private String auditorContact;

    /**
     * 审核员工号，数据库内加密
     */
    private String auditorWorkId;

    /**
     * open_id，可以为空
     */
    private String auditorOpenId;

    /**
     * 审核员单位主键，pci主键
     */
    private Long auditorBelonging;

    /**
     * 审核员单位名称
     */
    private String auditorBelongingName;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 创建者
     */
    private Long createUsr;

    /**
     * 修改者
     */
    private Long modifyUsr;

    /**
     * 逻辑删除
     */
    private Integer isdeleted;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AuditorInfo other = (AuditorInfo) that;
        return (this.getAuditorId() == null ? other.getAuditorId() == null : this.getAuditorId().equals(other.getAuditorId()))
            && (this.getAuditorName() == null ? other.getAuditorName() == null : this.getAuditorName().equals(other.getAuditorName()))
            && (this.getAuditorContact() == null ? other.getAuditorContact() == null : this.getAuditorContact().equals(other.getAuditorContact()))
            && (this.getAuditorWorkId() == null ? other.getAuditorWorkId() == null : this.getAuditorWorkId().equals(other.getAuditorWorkId()))
            && (this.getAuditorOpenId() == null ? other.getAuditorOpenId() == null : this.getAuditorOpenId().equals(other.getAuditorOpenId()))
            && (this.getAuditorBelonging() == null ? other.getAuditorBelonging() == null : this.getAuditorBelonging().equals(other.getAuditorBelonging()))
            && (this.getAuditorBelongingName() == null ? other.getAuditorBelongingName() == null : this.getAuditorBelongingName().equals(other.getAuditorBelongingName()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getModifyTime() == null ? other.getModifyTime() == null : this.getModifyTime().equals(other.getModifyTime()))
            && (this.getCreateUsr() == null ? other.getCreateUsr() == null : this.getCreateUsr().equals(other.getCreateUsr()))
            && (this.getModifyUsr() == null ? other.getModifyUsr() == null : this.getModifyUsr().equals(other.getModifyUsr()))
            && (this.getIsdeleted() == null ? other.getIsdeleted() == null : this.getIsdeleted().equals(other.getIsdeleted()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getAuditorId() == null) ? 0 : getAuditorId().hashCode());
        result = prime * result + ((getAuditorName() == null) ? 0 : getAuditorName().hashCode());
        result = prime * result + ((getAuditorContact() == null) ? 0 : getAuditorContact().hashCode());
        result = prime * result + ((getAuditorWorkId() == null) ? 0 : getAuditorWorkId().hashCode());
        result = prime * result + ((getAuditorOpenId() == null) ? 0 : getAuditorOpenId().hashCode());
        result = prime * result + ((getAuditorBelonging() == null) ? 0 : getAuditorBelonging().hashCode());
        result = prime * result + ((getAuditorBelongingName() == null) ? 0 : getAuditorBelongingName().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getModifyTime() == null) ? 0 : getModifyTime().hashCode());
        result = prime * result + ((getCreateUsr() == null) ? 0 : getCreateUsr().hashCode());
        result = prime * result + ((getModifyUsr() == null) ? 0 : getModifyUsr().hashCode());
        result = prime * result + ((getIsdeleted() == null) ? 0 : getIsdeleted().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", auditorId=").append(auditorId);
        sb.append(", auditorName=").append(auditorName);
        sb.append(", auditorContact=").append(auditorContact);
        sb.append(", auditorWorkId=").append(auditorWorkId);
        sb.append(", auditorOpenId=").append(auditorOpenId);
        sb.append(", auditorBelonging=").append(auditorBelonging);
        sb.append(", auditorBelongingName=").append(auditorBelongingName);
        sb.append(", createTime=").append(createTime);
        sb.append(", modifyTime=").append(modifyTime);
        sb.append(", createUsr=").append(createUsr);
        sb.append(", modifyUsr=").append(modifyUsr);
        sb.append(", isdeleted=").append(isdeleted);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}