package com.qll.chaindemo.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author ql66
 */
@RestController
@RequestMapping("/cpc")
@Slf4j
public class CpcController {










}
