package com.qll.chaindemo.service;

import com.qll.chaindemo.domain.NodeChainLog;

import java.time.LocalDateTime;

/**
* @author 86182
* @description 针对表【node_chain_log(单节点流程责任链表)】的数据库操作Service
* @createDate 2024-10-24 21:40:40
*/
public interface NodeChainLogService {

    long addNodeChainLog(NodeChainLog nodeChainLog1);

    public NodeChainLog generate(long chainID, String handlerName, Long handlerId, LocalDateTime startTime, int status, LocalDateTime createTime, Long createUsr, LocalDateTime modifyTime, Long modifyUsr) ;
}
