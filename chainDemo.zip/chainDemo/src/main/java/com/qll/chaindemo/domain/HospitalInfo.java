package com.qll.chaindemo.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 普通医院信息表
 * @TableName hospital_info
 */
@TableName(value ="hospital_info")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HospitalInfo implements Serializable {
    /**
     * 主键
     */
    @TableId
    private Long hstptId;

    /**
     * 地理位置
     */
    private String hstptLocation;

    /**
     * GPS位置-经度
     */
    private Double hstptGpsLongitude;

    /**
     * GPS位置-纬度
     */
    private Double hstptGpsLatitude;

    /**
     * 负责人联系电话
     */
    private String hstptContact;

    /**
     * 普通医院全称
     */
    private String hstptName;

    /**
     * 普通医院简称
     */
    private String hstptNameOmitted;

    /**
     * 普通医院简介（120字）
     */
    private String hstptIntroduction;

    /**
     * open_id，可以为空
     */
    private String hstptOpenId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 创建者
     */
    private Long createUsr;

    /**
     * 修改者
     */
    private Long modifyUsr;

    /**
     * 逻辑删除
     */
    private Integer isdeleted;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;



    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        HospitalInfo other = (HospitalInfo) that;
        return (this.getHstptId() == null ? other.getHstptId() == null : this.getHstptId().equals(other.getHstptId()))
            && (this.getHstptLocation() == null ? other.getHstptLocation() == null : this.getHstptLocation().equals(other.getHstptLocation()))
            && (this.getHstptGpsLongitude() == null ? other.getHstptGpsLongitude() == null : this.getHstptGpsLongitude().equals(other.getHstptGpsLongitude()))
            && (this.getHstptGpsLatitude() == null ? other.getHstptGpsLatitude() == null : this.getHstptGpsLatitude().equals(other.getHstptGpsLatitude()))
            && (this.getHstptContact() == null ? other.getHstptContact() == null : this.getHstptContact().equals(other.getHstptContact()))
            && (this.getHstptName() == null ? other.getHstptName() == null : this.getHstptName().equals(other.getHstptName()))
            && (this.getHstptNameOmitted() == null ? other.getHstptNameOmitted() == null : this.getHstptNameOmitted().equals(other.getHstptNameOmitted()))
            && (this.getHstptIntroduction() == null ? other.getHstptIntroduction() == null : this.getHstptIntroduction().equals(other.getHstptIntroduction()))
            && (this.getHstptOpenId() == null ? other.getHstptOpenId() == null : this.getHstptOpenId().equals(other.getHstptOpenId()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getModifyTime() == null ? other.getModifyTime() == null : this.getModifyTime().equals(other.getModifyTime()))
            && (this.getCreateUsr() == null ? other.getCreateUsr() == null : this.getCreateUsr().equals(other.getCreateUsr()))
            && (this.getModifyUsr() == null ? other.getModifyUsr() == null : this.getModifyUsr().equals(other.getModifyUsr()))
            && (this.getIsdeleted() == null ? other.getIsdeleted() == null : this.getIsdeleted().equals(other.getIsdeleted()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getHstptId() == null) ? 0 : getHstptId().hashCode());
        result = prime * result + ((getHstptLocation() == null) ? 0 : getHstptLocation().hashCode());
        result = prime * result + ((getHstptGpsLongitude() == null) ? 0 : getHstptGpsLongitude().hashCode());
        result = prime * result + ((getHstptGpsLatitude() == null) ? 0 : getHstptGpsLatitude().hashCode());
        result = prime * result + ((getHstptContact() == null) ? 0 : getHstptContact().hashCode());
        result = prime * result + ((getHstptName() == null) ? 0 : getHstptName().hashCode());
        result = prime * result + ((getHstptNameOmitted() == null) ? 0 : getHstptNameOmitted().hashCode());
        result = prime * result + ((getHstptIntroduction() == null) ? 0 : getHstptIntroduction().hashCode());
        result = prime * result + ((getHstptOpenId() == null) ? 0 : getHstptOpenId().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getModifyTime() == null) ? 0 : getModifyTime().hashCode());
        result = prime * result + ((getCreateUsr() == null) ? 0 : getCreateUsr().hashCode());
        result = prime * result + ((getModifyUsr() == null) ? 0 : getModifyUsr().hashCode());
        result = prime * result + ((getIsdeleted() == null) ? 0 : getIsdeleted().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", hstptId=").append(hstptId);
        sb.append(", hstptLocation=").append(hstptLocation);
        sb.append(", hstptGpsLongitude=").append(hstptGpsLongitude);
        sb.append(", hstptGpsLatitude=").append(hstptGpsLatitude);
        sb.append(", hstptContact=").append(hstptContact);
        sb.append(", hstptName=").append(hstptName);
        sb.append(", hstptNameOmitted=").append(hstptNameOmitted);
        sb.append(", hstptIntroduction=").append(hstptIntroduction);
        sb.append(", hstptOpenId=").append(hstptOpenId);
        sb.append(", createTime=").append(createTime);
        sb.append(", modifyTime=").append(modifyTime);
        sb.append(", createUsr=").append(createUsr);
        sb.append(", modifyUsr=").append(modifyUsr);
        sb.append(", isdeleted=").append(isdeleted);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}