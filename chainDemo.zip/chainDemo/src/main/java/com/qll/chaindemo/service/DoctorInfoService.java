package com.qll.chaindemo.service;

import com.qll.chaindemo.common.classes.HospitalRequest;
import com.qll.chaindemo.domain.DoctorInfo;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.HashMap;

/**
* @author 86182
* @description 针对表【doctor_info(主治医师信息表)】的数据库操作Service
* @createDate 2024-10-24 21:33:09
*/
public interface DoctorInfoService {

     void guideAmbulance(HospitalRequest request) ;

    HashMap<String, String> selectPatientAnd120(HospitalRequest request);

    void reform(HospitalRequest request);
}
