package com.qll.chaindemo.common.enums;

/**
 * @author 86182
 */
//作为角色的枚举
public enum RoleNameEnum {

     PATIENT("patient", "患者"),
     PCI("pci", "pci"),
     CPC("cpc", "cpc"),
     AUDITOR("auditor", "审核员"),
     ADMIN("admin", "管理员"),
     AMBULANCE("ambulance", " 救护车"),
     HOSPITAL("hospital", "基层医院");
    private String name;

    private final String description;

    RoleNameEnum(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }
}
