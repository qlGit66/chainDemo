package com.qll.chaindemo.mapper;

import com.qll.chaindemo.domain.NodeChainLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
* @author 86182
* @description 针对表【node_chain_log(单节点流程责任链表)】的数据库操作Mapper
* @createDate 2024-10-24 21:40:40
* @Entity generator.domain.NodeChainLog
*/
@Mapper
public interface NodeChainLogMapper extends BaseMapper<NodeChainLog> {

}




