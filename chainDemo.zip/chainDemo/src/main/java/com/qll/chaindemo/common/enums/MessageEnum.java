package com.qll.chaindemo.common.enums;

public enum MessageEnum {

     HOSPITAL_PATIENT_HOSPITAL("患者在基层医院呼救，目前在基层医院治疗"),
     HOSPITAL_PATIENT_PCI("患者在基层医院呼救，现在转移到PCI医院治疗"),
    HOSPITAL_PATIENT_AMBULANCE("患者在基层医院呼救，正在等待救护车"),
    HOSPITAL_PATIENT_OK("基层医院结束任务，患者已经转移"),

    AMBULANCE_PATIENT_COME("救护车去目标地"),
     AMBULANCE_PATIENT_PCI("救护车已经到达，现在转移到PCI医院治疗"),
     AMBULANCE_PATIENT_HOSPITAL("救护车已经到达，现在转移到基层医院治疗"),
     AMBULANCE_PATIENT_OK("救护车结束任务，患者已经转移");

    private String mess;

    MessageEnum(String s) {
         this.mess = s;
    }

    public String getMess() {
        return mess;
    }
}
