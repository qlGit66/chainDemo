package com.qll.chaindemo.service.impl;

import com.qll.chaindemo.domain.HealthRecords;
import com.qll.chaindemo.service.intelligentSystem;
import org.springframework.stereotype.Service;

@Service
//溶栓智能辅助系统
public class intelligentSystemImpl implements intelligentSystem {


    @Override
    public String getAdvice(HealthRecords healthRecords) {
        return "你自己怎么学的，自己去判断";
    }
}
