package com.qll.chaindemo.handerler;

import com.qll.chaindemo.common.classes.HospitalRequest;
import com.qll.chaindemo.domain.AmbulancesInfo;
import com.qll.chaindemo.domain.NodeChainLog;
import com.qll.chaindemo.interfaces.HospitalHandler;
import com.qll.chaindemo.service.DoctorInfoService;
import com.qll.chaindemo.service.NodeChainLogService;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
@Component
@Scope("prototype")
@Slf4j
public class pciHanderler implements HospitalHandler {

    private HospitalHandler nextHandler;

     @Resource
     private NodeChainLogService nodeChainLogService;
     @Resource
     private DoctorInfoService doctorInfoService;
    private HospitalRequest request;
    @Override
    public void setNextHandler(HospitalHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public AmbulancesInfo handleRequest(HospitalRequest request) {
       log.info("患者入院");
       log.info("医生开始治患者，发出指令");
        log.info("接诊医生开始自主填表");
        log.info("流程结束");
        return null;
    }

    public HospitalHandler getNextHandler() {
        return nextHandler;
    }
}
