package com.qll.chaindemo.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.qll.chaindemo.domain.ResponsibilityChainLog;
import com.qll.chaindemo.service.ResponsibilityChainLogService;
import com.qll.chaindemo.mapper.ResponsibilityChainLogMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

/**
* @author 86182
* @description 针对表【responsibility_chain_log(责任链处理记录表)】的数据库操作Service实现
* @createDate 2024-10-24 21:40:33
*/
@Service
public class ResponsibilityChainLogServiceImpl implements ResponsibilityChainLogService{
    @Resource
    private ResponsibilityChainLogMapper responsibilityChainLogMapper;
    @Override
    public long addResponsibilityChainLog(ResponsibilityChainLog responsibilityChainLog) {
          responsibilityChainLogMapper.insert(responsibilityChainLog);
          return responsibilityChainLog.getId();
    }
}




