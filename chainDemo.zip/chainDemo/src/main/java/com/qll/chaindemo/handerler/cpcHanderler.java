package com.qll.chaindemo.handerler;

import com.qll.chaindemo.common.classes.HospitalRequest;
import com.qll.chaindemo.common.enums.MessageEnum;
import com.qll.chaindemo.domain.AmbulancesInfo;
import com.qll.chaindemo.domain.NodeChainLog;
import com.qll.chaindemo.interfaces.HospitalHandler;
import com.qll.chaindemo.service.CpcInfoService;
import com.qll.chaindemo.service.HospitalInfoService;
import com.qll.chaindemo.service.NodeChainLogService;
import com.qll.chaindemo.service.intelligentSystem;
import jakarta.annotation.Resource;
import lombok.Locked;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
@Slf4j
@Component
@Scope("prototype")
public class cpcHanderler implements HospitalHandler {

    private HospitalHandler nextHandler;
    private HospitalRequest request;
    @Resource
    private HospitalInfoService hospitalInfoService;
    @Resource
    private NodeChainLogService nodeChainLogService;
    @Resource
    private CpcInfoService cpcInfoService;
    @Override
    public void setNextHandler(HospitalHandler nextHandler) {
         this.nextHandler = nextHandler;
    }
   @Resource
   private ambulanceHanderler ambulanceHanderler;
    @Resource
    private intelligentSystem intelligentSystem;
     //在这里做所有的病人前后的逻辑，只有病人在pci医院时责任链转移
    @Override
    public AmbulancesInfo handleRequest(HospitalRequest request) {
        log.info("先给救护车发请求");
         AmbulancesInfo ambulancesInfo =    cpcInfoService.findAmbulance();
         request.setAmbulancesInfo( ambulancesInfo);
         log.info("救护车到了");
         //给pci医院发送请求
        log.info("pci医院请求");
        cpcInfoService.sendRequestPCI(request);

         //假定救护车已经到达
        //1.写的节点
        log.info(" 救护车节点启动");
        request.setMessage(MessageEnum.AMBULANCE_PATIENT_PCI.getMess());
      NodeChainLog nodeChainLog =   nodeChainLogService.generate( request.getChainId(),ambulancesInfo.getChargeName(),ambulancesInfo.getAmbulanceId(), LocalDateTime.now(),0,
                LocalDateTime.now(),ambulancesInfo.getAmbulanceId(),LocalDateTime.now(),ambulancesInfo.getAmbulanceId());
      nodeChainLog.setId(request.getNodeId());
      //这个代表责任链节点的变更
        long nodeId = nodeChainLogService.addNodeChainLog(nodeChainLog);
        request.setNodeId(nodeId);

        this.nextHandler =  ambulanceHanderler;
        //这时候上传患者信息
        log.info("同步上传患者信息");
        log.info("救护车根据系统判断");
        String advice = intelligentSystem.getAdvice(request.getHealthRecords());
        log.info("救护车根据系统判断"+advice);
        //患者到达PCI医院，开始交棒
        log.info("患者到达PCI医院，开始交棒");
        ambulanceHanderler.handleRequest(request);
        return ambulancesInfo;
    }

    public HospitalHandler getNextHandler() {
        return nextHandler;
    }
}
