package com.qll.chaindemo.service;

import com.qll.chaindemo.common.classes.HospitalRequest;
import com.qll.chaindemo.domain.AmbulancesInfo;
import com.qll.chaindemo.domain.HealthRecords;

import java.util.HashMap;

/**
* @author 86182
* @description 针对表【cpc_info(调度中心信息表)】的数据库操作Service
* @createDate 2024-10-24 21:39:27
*/
public interface CpcInfoService  {

    void call(HealthRecords healthRecords);

    AmbulancesInfo findAmbulance();

    HashMap<String, String> sendRequestPCI(HospitalRequest request);
}
