package com.qll.chaindemo.mapper;

import com.qll.chaindemo.domain.CpcInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
* @author 86182
* @description 针对表【cpc_info(调度中心信息表)】的数据库操作Mapper
* @createDate 2024-10-24 21:39:27
* @Entity generator.domain.CpcInfo
*/
@Mapper
public interface CpcInfoMapper extends BaseMapper<CpcInfo> {

}




