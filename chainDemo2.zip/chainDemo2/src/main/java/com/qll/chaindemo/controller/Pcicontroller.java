package com.qll.chaindemo.controller;

import com.qll.chaindemo.common.classes.Result;
import com.qll.chaindemo.common.enums.ResultCodeEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequestMapping("/pci")
public class Pcicontroller {

        //cpc医院 发送通知给pci医院
    @PostMapping("/send/request")
      public Result cpcSendRequest(String message){
           return Result.success(ResultCodeEnum.SUCCESS);
      }



}
