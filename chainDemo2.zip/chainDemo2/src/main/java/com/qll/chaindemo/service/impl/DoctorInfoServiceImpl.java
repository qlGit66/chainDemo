package com.qll.chaindemo.service.impl;

import com.qll.chaindemo.common.classes.ChainData;
import com.qll.chaindemo.domain.AmbulancesInfo;
import com.qll.chaindemo.domain.HealthRecords;
import com.qll.chaindemo.mapper.AmbulancesInfoMapper;
import com.qll.chaindemo.mapper.HealthRecordsMapper;
import com.qll.chaindemo.service.DoctorInfoService;
import com.qll.chaindemo.mapper.DoctorInfoMapper;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashMap;

/**
* @author 86182
* @description 针对表【doctor_info(主治医师信息表)】的数据库操作Service实现
* @createDate 2024-10-24 21:33:09
*/@Slf4j
@Service
public class DoctorInfoServiceImpl implements DoctorInfoService{

     @Resource
    private DoctorInfoMapper doctorInfoMapper;
     @Resource
    private AmbulancesInfoMapper ambulancesInfoMapper;
     @Resource
    private HealthRecordsMapper healthRecordsMapper;

    @Override
    public void guideAmbulance(ChainData request) {

    }

    @Override
    public HashMap<String, String> selectPatientAnd120(ChainData request) {
        log.info("医生开始查看并给出分析");
        AmbulancesInfo ambulancesInfo = ambulancesInfoMapper.selectById(request.getAmbulancesInfo().getAmbulanceId());
        HealthRecords healthRecords = healthRecordsMapper.selectById(request.getHealthRecords().getPatientId());
       log.info("医生自己通知医院接受部门。告知预计抵达时间");

        return null;
    }

    @Override
    public void reform(ChainData request) {

    }
}




