package com.qll.chaindemo.service.impl;

import com.qll.chaindemo.domain.NodeChainLog;
import com.qll.chaindemo.service.NodeChainLogService;
import com.qll.chaindemo.mapper.NodeChainLogMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
* @author 86182
* @description 针对表【node_chain_log(单节点流程责任链表)】的数据库操作Service实现
* @createDate 2024-10-24 21:40:40
*/
@Service
public class NodeChainLogServiceImpl implements NodeChainLogService{
    @Resource
    private NodeChainLogMapper nodeChainLogMapper;
    @Override
    public long addNodeChainLog(NodeChainLog nodeChainLog)
    {
        NodeChainLog nodeChainLog1 = nodeChainLogMapper.selectById(nodeChainLog.getId());
        if(nodeChainLog1==null){
           nodeChainLogMapper.insert(nodeChainLog);

        }
        else {
             nodeChainLogMapper.updateById(nodeChainLog);
        }
        return nodeChainLog.getId();
    }

    @Override
    public NodeChainLog generate(long chainID, String handlerName, Long handlerId, LocalDateTime startTime, int status, LocalDateTime createTime, Long createUsr, LocalDateTime modifyTime, Long modifyUsr) {
        NodeChainLog nodeChainLog = NodeChainLog.builder()
                .chainId(chainID).handlerName(handlerName).handlerId(handlerId).startTime(startTime).status(status).createTime(createTime).createUsr(createUsr).modifyTime(modifyTime).modifyUsr(modifyUsr).build();
           nodeChainLog.setCreateUsr(1L);
           nodeChainLog.setModifyUsr(1L);
        return  nodeChainLog;
    }
}




