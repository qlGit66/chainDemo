package com.qll.chaindemo.mapper;

import com.qll.chaindemo.domain.HealthRecords;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
* @author 86182
* @description 针对表【health_records(存储患者基本信息的表格)】的数据库操作Mapper
* @createDate 2024-10-24 21:40:52
* @Entity generator.domain.HealthRecords
*/
@Mapper
public interface HealthRecordsMapper extends BaseMapper<HealthRecords> {

}




