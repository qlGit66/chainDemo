package com.qll.chaindemo.controller;

import com.qll.chaindemo.common.classes.Result;
import com.qll.chaindemo.common.enums.ResultCodeEnum;
import com.qll.chaindemo.domain.DoctorInfo;
import com.qll.chaindemo.domain.HealthRecords;
import com.qll.chaindemo.domain.HospitalInfo;
import com.qll.chaindemo.service.HealthRecordsService;
import com.qll.chaindemo.service.intelligentSystem;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.Queue;

/**
 * @author 86182
 */
@RestController
@RequestMapping("/ambulance")
@Slf4j
public class AmbulanceController {

      @Resource
      private HealthRecordsService healthRecordsService;

    @Resource
    private intelligentSystem intelligentSystem;
       //得到cpc通知

       @PostMapping("/notice")
       public Result  getNotice(String message){
             return Result.success(ResultCodeEnum.SUCCESS);
       }

       //得到cpc告知的推荐医院
       @PostMapping("/recommend/hospital")
    public Result getRecommendHospital(String message,@RequestBody HospitalInfo hospitalInfo){


           return Result.success(ResultCodeEnum.SUCCESS);
       }

       //接到患者后，创建或读取健康档案
      @PostMapping("/healthRecords")
    public Result createHealthRecords(@RequestBody HealthRecords healthRecords){


          healthRecordsService.addHealthRecords(healthRecords);
          return Result.success(ResultCodeEnum.SUCCESS);
      }
      //通过智能系统来得出建议
      @GetMapping("/smartSystem")
    public Result getAdvice(@RequestBody HealthRecords healthRecords){

          String advice = intelligentSystem.getAdvice(healthRecords);

          return Result.success(advice);
      }

      //系统智能分析转运时间
      @GetMapping("/analysis/time/pci")
    public Result analysis(){
          String advice = intelligentSystem.getAdvice(null);
          return Result.success(advice);
      }

      //上传患者数据、救治过程和决策医生
    @PostMapping("/upload/doctorAndHospital")
    public Result uploadDoctorInfo(@RequestBody HospitalInfo hospitalInfo,@RequestBody DoctorInfo doctorInfo){
        return Result.success(ResultCodeEnum.SUCCESS);
    }
}
