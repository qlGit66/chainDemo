package com.qll.chaindemo.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * 单节点流程责任链表
 * @TableName node_chain_log
 */
@TableName(value ="node_chain_log")
@Data
@Builder
@AllArgsConstructor
public class NodeChainLog implements Serializable {
    /**
     * 建议自增
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 属于哪条责任链
     */
    private Long chainId;

    /**
     * 处理者名称
     */
    private String handlerName;

    /**
     * 处理者ID
     */
    private Long handlerId;

    /**
     * 开始时间
     */
    private LocalDateTime startTime;

    /**
     * 结束时间
     */
    private LocalDateTime endTime;

    /**
     * 节点处理状态（完成、失败、等待中）
     */
    private Integer status;

    /**
     * 
     */
    private LocalDateTime createTime;

    /**
     * 
     */
    private Long createUsr;

    /**
     * 
     */
    private LocalDateTime modifyTime;

    /**
     * 
     */
    private Long modifyUsr;

    /**
     * 
     */
    private Integer isdeleted;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    public NodeChainLog() {
        this.createTime = LocalDateTime.now();
        this.modifyTime = LocalDateTime.now();
        this.createUsr = 1L;
        this.modifyUsr = 1L;
    }
}