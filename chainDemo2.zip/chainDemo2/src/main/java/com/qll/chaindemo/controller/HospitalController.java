package com.qll.chaindemo.controller;

import com.qll.chaindemo.common.classes.ChainData;
import com.qll.chaindemo.common.classes.Result;
import com.qll.chaindemo.service.intelligentSystem;
import com.qll.chaindemo.common.enums.MessageEnum;
import com.qll.chaindemo.common.enums.ResultCodeEnum;
import com.qll.chaindemo.domain.*;
import com.qll.chaindemo.handerler.baseHospitalHandler;
import com.qll.chaindemo.service.*;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

/**
 * @author 86182
 * 1.加task表
 * 2. 拆接口
 */
@RestController
@Slf4j
@RequestMapping("/hospital")
public class HospitalController {

    @Resource
    private CpcInfoService cpcInfoService;

    @Resource
    private ResponsibilityChainLogService responsibilityChainLog;

    @Resource
    private NodeChainLogService nodeChainLog;
    @Resource
    private baseHospitalHandler baseHospitalHandler;
    @Resource
    private HealthRecordsService healthRecordsService;
    @Resource
    private intelligentSystem intelligentSystem;

    //填入或修改健康档案
@PostMapping("/add/healthRecords")
    public Result addHealthRecords(@RequestBody  HealthRecords healthRecords){

        healthRecordsService.addHealthRecords(healthRecords);

        return Result.success(ResultCodeEnum.SUCCESS);
    }
  //得知救护车信息
  @PostMapping("/tell/ambulance")
  public Result tellAmbulance(@RequestBody  AmbulancesInfo ambulancesInfo){

        return Result.success(ambulancesInfo);
    }

    //智能分析溶栓
    @GetMapping("/smartSystem")
    public Result getAdvice(@RequestBody HealthRecords healthRecords){
        String advice = intelligentSystem.getAdvice(healthRecords);
        return Result.success(advice);
    }

     //被 120 告知已经抵达
    @PostMapping("/ambulance/arrive")
    public Result getAmbulanceOk(String message){
        log.info("救护车已经到医院");
        return Result.success(ResultCodeEnum.SUCCESS);
    }








    //医院开始 运输链
    @GetMapping("/start/{id}")
    public Result start(@PathVariable long id ){
        HospitalInfo hospitalInfo = new HospitalInfo();
        HealthRecords healthRecords = new HealthRecords();



        log.info("开始填加新责任链");
       long chainID =    responsibilityChainLog.addResponsibilityChainLog(new ResponsibilityChainLog());
       log.info("记录第一个节点");
       //添加第一个责任节点
        NodeChainLog chainLog =    nodeChainLog.generate(chainID,hospitalInfo.getHstptNameOmitted(),hospitalInfo.getHstptId()
               ,LocalDateTime.now(),0,LocalDateTime.now(),hospitalInfo.getHstptId(),LocalDateTime.now(),hospitalInfo.getHstptId());

      long nodeId =   nodeChainLog.addNodeChainLog(chainLog);

        ChainData request = ChainData.builder()
                .healthRecords(healthRecords)
                .chainId(chainID)
                .message(MessageEnum.HOSPITAL_PATIENT_HOSPITAL.getMess())
                .nodeId(nodeId)
                .build();
        log.info("开始运输链");

        //返回救护车信息
      AmbulancesInfo ambulancesInfo =    baseHospitalHandler.handleRequest(request);
         return Result.success(ambulancesInfo);
    }


}
