package com.qll.chaindemo.service;

import com.qll.chaindemo.common.classes.ChainData;

import java.util.HashMap;

/**
* @author 86182
* @description 针对表【doctor_info(主治医师信息表)】的数据库操作Service
* @createDate 2024-10-24 21:33:09
*/
public interface DoctorInfoService {

     void guideAmbulance(ChainData request) ;

    HashMap<String, String> selectPatientAnd120(ChainData request);

    void reform(ChainData request);
}
