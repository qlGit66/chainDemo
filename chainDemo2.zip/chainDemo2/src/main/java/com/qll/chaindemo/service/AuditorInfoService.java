package com.qll.chaindemo.service;

import com.qll.chaindemo.domain.AuditorInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 86182
* @description 针对表【auditor_info(审核员信息表)】的数据库操作Service
* @createDate 2024-10-24 21:33:24
*/
public interface AuditorInfoService extends IService<AuditorInfo> {

}
