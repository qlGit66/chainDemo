package com.qll.chaindemo.service;

import com.qll.chaindemo.domain.HealthRecords;

/**
 * @author 86182
 */
public interface intelligentSystem {
    String getAdvice(HealthRecords healthRecords);
}
