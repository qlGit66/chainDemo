package com.qll.chaindemo.mapper;

import com.qll.chaindemo.domain.AuditorInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
* @author 86182
* @description 针对表【auditor_info(审核员信息表)】的数据库操作Mapper
* @createDate 2024-10-24 21:33:24
* @Entity generator.domain.AuditorInfo
*/
@Mapper
public interface AuditorInfoMapper extends BaseMapper<AuditorInfo> {

}




