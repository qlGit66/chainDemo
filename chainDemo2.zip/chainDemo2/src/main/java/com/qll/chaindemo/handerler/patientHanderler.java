package com.qll.chaindemo.handerler;

import com.qll.chaindemo.common.classes.ChainData;
import com.qll.chaindemo.domain.AmbulancesInfo;
import com.qll.chaindemo.interfaces.HospitalHandler;
import com.qll.chaindemo.service.HealthRecordsService;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @author 86182
 */
@Slf4j
@Component
@Scope("prototype")
public class patientHanderler implements HospitalHandler {

    private HospitalHandler nextHandler;

    @Resource
    private HealthRecordsService healthRecords;

    @Override
    public void setNextHandler(HospitalHandler nextHandler) {
             this.nextHandler = nextHandler;
    }

    @Override
    public AmbulancesInfo handleRequest(ChainData request) {


        return null;
    }
}
