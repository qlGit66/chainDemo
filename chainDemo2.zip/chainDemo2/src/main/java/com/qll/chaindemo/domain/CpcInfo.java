package com.qll.chaindemo.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 调度中心信息表
 * @TableName cpc_info
 */
@TableName(value ="cpc_info")
@Data
public class CpcInfo implements Serializable {
    /**
     * 主键
     */
    @TableId
    private Long cpcId;

    /**
     * 地理位置
     */
    private String cpcLocation;

    /**
     * GPS位置-经度
     */
    private Double cpcGpsLongitude;

    /**
     * GPS位置-纬度
     */
    private Double cpcGpsLatitude;

    /**
     * 负责人联系电话
     */
    private String cpcContact;

    /**
     * 调度中心全称
     */
    private String cpcName;

    /**
     * 调度中心简称
     */
    private String cpcNameOmitted;

    /**
     * 调度中心简介（120字）
     */
    private String cpcIntroduction;

    /**
     * open_id 可以为空
     */
    private String hstptOpenId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 创建者
     */
    private Long createUsr;

    /**
     * 修改者
     */
    private Long modifyUsr;

    /**
     * 逻辑删除
     */
    private Integer isdeleted;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        CpcInfo other = (CpcInfo) that;
        return (this.getCpcId() == null ? other.getCpcId() == null : this.getCpcId().equals(other.getCpcId()))
            && (this.getCpcLocation() == null ? other.getCpcLocation() == null : this.getCpcLocation().equals(other.getCpcLocation()))
            && (this.getCpcGpsLongitude() == null ? other.getCpcGpsLongitude() == null : this.getCpcGpsLongitude().equals(other.getCpcGpsLongitude()))
            && (this.getCpcGpsLatitude() == null ? other.getCpcGpsLatitude() == null : this.getCpcGpsLatitude().equals(other.getCpcGpsLatitude()))
            && (this.getCpcContact() == null ? other.getCpcContact() == null : this.getCpcContact().equals(other.getCpcContact()))
            && (this.getCpcName() == null ? other.getCpcName() == null : this.getCpcName().equals(other.getCpcName()))
            && (this.getCpcNameOmitted() == null ? other.getCpcNameOmitted() == null : this.getCpcNameOmitted().equals(other.getCpcNameOmitted()))
            && (this.getCpcIntroduction() == null ? other.getCpcIntroduction() == null : this.getCpcIntroduction().equals(other.getCpcIntroduction()))
            && (this.getHstptOpenId() == null ? other.getHstptOpenId() == null : this.getHstptOpenId().equals(other.getHstptOpenId()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getModifyTime() == null ? other.getModifyTime() == null : this.getModifyTime().equals(other.getModifyTime()))
            && (this.getCreateUsr() == null ? other.getCreateUsr() == null : this.getCreateUsr().equals(other.getCreateUsr()))
            && (this.getModifyUsr() == null ? other.getModifyUsr() == null : this.getModifyUsr().equals(other.getModifyUsr()))
            && (this.getIsdeleted() == null ? other.getIsdeleted() == null : this.getIsdeleted().equals(other.getIsdeleted()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getCpcId() == null) ? 0 : getCpcId().hashCode());
        result = prime * result + ((getCpcLocation() == null) ? 0 : getCpcLocation().hashCode());
        result = prime * result + ((getCpcGpsLongitude() == null) ? 0 : getCpcGpsLongitude().hashCode());
        result = prime * result + ((getCpcGpsLatitude() == null) ? 0 : getCpcGpsLatitude().hashCode());
        result = prime * result + ((getCpcContact() == null) ? 0 : getCpcContact().hashCode());
        result = prime * result + ((getCpcName() == null) ? 0 : getCpcName().hashCode());
        result = prime * result + ((getCpcNameOmitted() == null) ? 0 : getCpcNameOmitted().hashCode());
        result = prime * result + ((getCpcIntroduction() == null) ? 0 : getCpcIntroduction().hashCode());
        result = prime * result + ((getHstptOpenId() == null) ? 0 : getHstptOpenId().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getModifyTime() == null) ? 0 : getModifyTime().hashCode());
        result = prime * result + ((getCreateUsr() == null) ? 0 : getCreateUsr().hashCode());
        result = prime * result + ((getModifyUsr() == null) ? 0 : getModifyUsr().hashCode());
        result = prime * result + ((getIsdeleted() == null) ? 0 : getIsdeleted().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", cpcId=").append(cpcId);
        sb.append(", cpcLocation=").append(cpcLocation);
        sb.append(", cpcGpsLongitude=").append(cpcGpsLongitude);
        sb.append(", cpcGpsLatitude=").append(cpcGpsLatitude);
        sb.append(", cpcContact=").append(cpcContact);
        sb.append(", cpcName=").append(cpcName);
        sb.append(", cpcNameOmitted=").append(cpcNameOmitted);
        sb.append(", cpcIntroduction=").append(cpcIntroduction);
        sb.append(", hstptOpenId=").append(hstptOpenId);
        sb.append(", createTime=").append(createTime);
        sb.append(", modifyTime=").append(modifyTime);
        sb.append(", createUsr=").append(createUsr);
        sb.append(", modifyUsr=").append(modifyUsr);
        sb.append(", isdeleted=").append(isdeleted);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}