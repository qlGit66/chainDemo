package com.qll.chaindemo.controller;

import org.springframework.web.bind.annotation.*;

/**
 * @author 86182
 */
@RestController
@RequestMapping(" /doctor")
public class DoctorController {

     //查询患者状态和救护车到达时间
    @GetMapping("/patientStatus/ambulanceArrivalTime")
    public String analysis(){
        return "analysis";
    }
    //pCI医院给医生反馈接受部门
    @PostMapping("/pci/doctor/feedback")
    public String feedback(){
        return "feedback";
    }


}
