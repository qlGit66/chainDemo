package com.qll.chaindemo.mapper;

import com.qll.chaindemo.domain.ResponsibilityChainLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
* @author 86182
* @description 针对表【responsibility_chain_log(责任链处理记录表)】的数据库操作Mapper
* @createDate 2024-10-24 21:40:33
* @Entity generator.domain.ResponsibilityChainLog
*/
@Mapper
public interface ResponsibilityChainLogMapper extends BaseMapper<ResponsibilityChainLog> {

}




