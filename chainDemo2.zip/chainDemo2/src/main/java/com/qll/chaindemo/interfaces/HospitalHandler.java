package com.qll.chaindemo.interfaces;

import com.qll.chaindemo.common.classes.ChainData;
import com.qll.chaindemo.domain.AmbulancesInfo;

public interface HospitalHandler {
    void setNextHandler(HospitalHandler nextHandler);
    AmbulancesInfo handleRequest(ChainData request);
}
