package com.qll.chaindemo.mapper;

import com.qll.chaindemo.domain.AmbulancesInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
* @author 86182
* @description 针对表【ambulances_info(救护车信息表)】的数据库操作Mapper
* @createDate 2024-10-24 21:33:30
* @Entity generator.domain.AmbulancesInfo
*/
@Mapper
public interface AmbulancesInfoMapper extends BaseMapper<AmbulancesInfo> {

}




