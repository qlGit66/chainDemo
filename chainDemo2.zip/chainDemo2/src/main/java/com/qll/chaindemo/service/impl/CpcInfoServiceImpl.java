package com.qll.chaindemo.service.impl;

import com.qll.chaindemo.common.classes.ChainData;
import com.qll.chaindemo.domain.AmbulancesInfo;
import com.qll.chaindemo.domain.HealthRecords;
import com.qll.chaindemo.mapper.AmbulancesInfoMapper;
import com.qll.chaindemo.service.CpcInfoService;
import com.qll.chaindemo.mapper.CpcInfoMapper;
import com.qll.chaindemo.service.HealthRecordsService;
import com.qll.chaindemo.service.PciService;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

/**
* @author 86182
* @description 针对表【cpc_info(调度中心信息表)】的数据库操作Service实现
* @createDate 2024-10-24 21:39:27
*/
@Slf4j
@Service
public class CpcInfoServiceImpl implements CpcInfoService{
    @Resource
    private HealthRecordsService healthRecordsService;
     @Resource
     private CpcInfoMapper cpcInfoMapper;
      @Resource
      private AmbulancesInfoMapper ambulancesInfoMapper;
      @Resource
      private PciService pciService;
    @Override
    public void call(HealthRecords healthRecords) {

    }

    @Override
    public AmbulancesInfo findAmbulance() {
        log.info("开始寻找救护车");
        List<AmbulancesInfo> ambulancesInfos = ambulancesInfoMapper.selectList(null);
        return ambulancesInfos.get(0);
    }
      //返回的是医生的解决方案
    @Override
    public HashMap<String, String> sendRequestPCI(ChainData request) {
        return pciService.getRequest(request);
    }
}




