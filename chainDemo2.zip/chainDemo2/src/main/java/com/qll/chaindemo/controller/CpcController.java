package com.qll.chaindemo.controller;
import com.qll.chaindemo.domain.DoctorInfo;
import com.qll.chaindemo.domain.Dto.HealthRecordsDto;
import com.qll.chaindemo.domain.HealthRecords;
import com.qll.chaindemo.domain.HospitalInfo;
import com.qll.chaindemo.service.intelligentSystem;
import com.qll.chaindemo.common.classes.Result;
import com.qll.chaindemo.common.enums.ResultCodeEnum;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

/**
 * @author ql66
 */
@RestController
@RequestMapping("/cpc")
@Slf4j
public class CpcController {


     @Resource
     private intelligentSystem intelligentSystem;
     //被呼救
    @PostMapping("/call")
    public Result getHospitalCall(String message){
        return Result.success(ResultCodeEnum.SUCCESS);
    }
   //智能调度
   @GetMapping("/smartSystem")
    public Result getAdvice(@RequestBody HealthRecords healthRecords){
       String advice = intelligentSystem.getAdvice(healthRecords);
       return Result.success(advice);
   }
   //得知救护车确认
   @PostMapping("/ambulance/ok")
    public Result getAmbulanceOk(String message){
        return Result.success(ResultCodeEnum.SUCCESS);
    }

    //得知 pci医院确认
    @PostMapping("/pci/ok")
    public Result getPciOk(String message){
        return Result.success(ResultCodeEnum.SUCCESS);
    }

    //智能分析，得到推荐医院
    @GetMapping("/analysis/recommend/hospital")
    public Result analysis(){
        String advice = intelligentSystem.getAdvice(null);
        return Result.success(advice);
    }

    //救护车确认患者需要 进行pci
    @PostMapping("/ambulance/pci")
    public Result getAmbulancePci(String message){
        return Result.success(ResultCodeEnum.SUCCESS);
    }
    //被救护车告知无法送往
    @PostMapping("/ambulance/canNot/come")
    public Result getAmbulanceCanNotCome(String message){
        return Result.success(ResultCodeEnum.SUCCESS);
    }
    //被救护车告知送往的医院信息
    @PostMapping("/ambulance/can/come/hospitalInfo")
    public Result getAmbulanceComeHospitalInfo(@RequestBody HospitalInfo hospitalInfo){
        return Result.success(ResultCodeEnum.SUCCESS);
    }
    //得到pci医院给的主治医师信息
    @GetMapping("/pci/doctor/info")
    public Result getPciDoctorInfo(@RequestBody DoctorInfo doctorInfo){
        return Result.success(ResultCodeEnum.SUCCESS);
    }
    //上传 医院和主治医师信息
    @PostMapping("/upload/doctorAndHospital")
    public Result uploadDoctorInfo(@RequestBody DoctorInfo doctorInfo,@RequestBody HospitalInfo hospitalInfo){
        return Result.success(ResultCodeEnum.SUCCESS);
    }
    //创建会诊群组
    @PostMapping("/create/group")
    public Result createGroup(String message){
        return Result.success(ResultCodeEnum.SUCCESS);
    }

}
