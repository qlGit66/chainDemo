package com.qll.chaindemo.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 主治医师信息表
 * @TableName doctor_info
 */
@TableName(value ="doctor_info")
@Data
public class DoctorInfo implements Serializable {
    /**
     * 主治医师主键，雪花算法
     */
    @TableId
    private Long doctorId;

    /**
     * 主治医生姓名，数据库内加密
     */
    private String doctorName;

    /**
     * 主治医生手机号，数据库内加密
     */
    private String doctorContact;

    /**
     * 主治医生工号，数据库内加密
     */
    private String doctorWorkId;

    /**
     * 主治医生简介，100字以内，数据库内加密
     */
    private String doctorOmitted;

    /**
     * open_id
     */
    private String doctorOpenId;

    /**
     * 主治医师单位主键，普通医院主键
     */
    private Long doctorBelonging;

    /**
     * 主治医师单位名称
     */
    private String doctorBelongingName;

    /**
     * 主治医师工作状态：0无法参与急救/1可以参与急救
     */
    private Integer doctorStatus;

    /**
     * 注册状态：0注册待审核/1注册成功
     */
    private Integer registerStatus;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 创建者
     */
    private Long createUsr;

    /**
     * 修改者
     */
    private Long modifyUsr;

    /**
     * 逻辑删除
     */
    private Integer isdeleted;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        DoctorInfo other = (DoctorInfo) that;
        return (this.getDoctorId() == null ? other.getDoctorId() == null : this.getDoctorId().equals(other.getDoctorId()))
            && (this.getDoctorName() == null ? other.getDoctorName() == null : this.getDoctorName().equals(other.getDoctorName()))
            && (this.getDoctorContact() == null ? other.getDoctorContact() == null : this.getDoctorContact().equals(other.getDoctorContact()))
            && (this.getDoctorWorkId() == null ? other.getDoctorWorkId() == null : this.getDoctorWorkId().equals(other.getDoctorWorkId()))
            && (this.getDoctorOmitted() == null ? other.getDoctorOmitted() == null : this.getDoctorOmitted().equals(other.getDoctorOmitted()))
            && (this.getDoctorOpenId() == null ? other.getDoctorOpenId() == null : this.getDoctorOpenId().equals(other.getDoctorOpenId()))
            && (this.getDoctorBelonging() == null ? other.getDoctorBelonging() == null : this.getDoctorBelonging().equals(other.getDoctorBelonging()))
            && (this.getDoctorBelongingName() == null ? other.getDoctorBelongingName() == null : this.getDoctorBelongingName().equals(other.getDoctorBelongingName()))
            && (this.getDoctorStatus() == null ? other.getDoctorStatus() == null : this.getDoctorStatus().equals(other.getDoctorStatus()))
            && (this.getRegisterStatus() == null ? other.getRegisterStatus() == null : this.getRegisterStatus().equals(other.getRegisterStatus()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getModifyTime() == null ? other.getModifyTime() == null : this.getModifyTime().equals(other.getModifyTime()))
            && (this.getCreateUsr() == null ? other.getCreateUsr() == null : this.getCreateUsr().equals(other.getCreateUsr()))
            && (this.getModifyUsr() == null ? other.getModifyUsr() == null : this.getModifyUsr().equals(other.getModifyUsr()))
            && (this.getIsdeleted() == null ? other.getIsdeleted() == null : this.getIsdeleted().equals(other.getIsdeleted()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getDoctorId() == null) ? 0 : getDoctorId().hashCode());
        result = prime * result + ((getDoctorName() == null) ? 0 : getDoctorName().hashCode());
        result = prime * result + ((getDoctorContact() == null) ? 0 : getDoctorContact().hashCode());
        result = prime * result + ((getDoctorWorkId() == null) ? 0 : getDoctorWorkId().hashCode());
        result = prime * result + ((getDoctorOmitted() == null) ? 0 : getDoctorOmitted().hashCode());
        result = prime * result + ((getDoctorOpenId() == null) ? 0 : getDoctorOpenId().hashCode());
        result = prime * result + ((getDoctorBelonging() == null) ? 0 : getDoctorBelonging().hashCode());
        result = prime * result + ((getDoctorBelongingName() == null) ? 0 : getDoctorBelongingName().hashCode());
        result = prime * result + ((getDoctorStatus() == null) ? 0 : getDoctorStatus().hashCode());
        result = prime * result + ((getRegisterStatus() == null) ? 0 : getRegisterStatus().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getModifyTime() == null) ? 0 : getModifyTime().hashCode());
        result = prime * result + ((getCreateUsr() == null) ? 0 : getCreateUsr().hashCode());
        result = prime * result + ((getModifyUsr() == null) ? 0 : getModifyUsr().hashCode());
        result = prime * result + ((getIsdeleted() == null) ? 0 : getIsdeleted().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", doctorId=").append(doctorId);
        sb.append(", doctorName=").append(doctorName);
        sb.append(", doctorContact=").append(doctorContact);
        sb.append(", doctorWorkId=").append(doctorWorkId);
        sb.append(", doctorOmitted=").append(doctorOmitted);
        sb.append(", doctorOpenId=").append(doctorOpenId);
        sb.append(", doctorBelonging=").append(doctorBelonging);
        sb.append(", doctorBelongingName=").append(doctorBelongingName);
        sb.append(", doctorStatus=").append(doctorStatus);
        sb.append(", registerStatus=").append(registerStatus);
        sb.append(", createTime=").append(createTime);
        sb.append(", modifyTime=").append(modifyTime);
        sb.append(", createUsr=").append(createUsr);
        sb.append(", modifyUsr=").append(modifyUsr);
        sb.append(", isdeleted=").append(isdeleted);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}