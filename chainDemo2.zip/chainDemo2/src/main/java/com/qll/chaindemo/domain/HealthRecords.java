package com.qll.chaindemo.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * 存储患者基本信息的表格
 * @TableName health_records
 */
@TableName(value ="health_records")
@Data
public class HealthRecords implements Serializable  {
    /**
     * 主键，使用雪花算法生成
     */
    @TableId
    private Long patientId;

    /**
     * 患者编号，使用二维码
     */
    private String patientNumber;

    /**
     * 患者姓名
     */
    private String patientName;

    /**
     * 患者性别，1表示男，2表示女
     */
    private Integer gender;

    /**
     * 年龄
     */
    private Integer age;

    /**
     * 联系人
     */
    private String contact;

    /**
     * 联系电话
     */
    private String telephoneNumber;

    /**
     * 住院号
     */
    private String admissionNumber;

    /**
     * 身份证号
     */
    private String id;

    /**
     * 入选胸痛/入选心梗，1表示胸痛，2表示心梗
     */
    private Integer chestpainOrHeartattack;

    /**
     * 发病时间
     */
    private Date diseaseTime;

    /**
     * 精确到分钟，0表示否，1表示是
     */
    private Integer ifAccurate;

    /**
     * 有无呼救，0表示否，1表示是
     */
    private Integer ifHelp;

    /**
     * 发病地址，待定具体含义
     */
    private Integer diseaseAddress;

    /**
     * 来院方式，待定具体含义
     */
    private Integer source;

    /**
     * 患者地址
     */
    private String patientAddress;

    /**
     * 院内首次治疗时间
     */
    private Date firstTreatTimeHstpt;

    /**
     * 院内首次心电图完成时间
     */
    private Date firstEcgTimeHstpt;

    /**
     * 心电图路径，单个路径按下划线分割,多个路径按百分号分割
     */
    private String firstEcgPathHstpt;

    /**
     * 首份心电图确诊时间
     */
    private Date firstEcgDefineTime;

    /**
     * 远程心电传输，待定具体含义
     */
    private Integer remoteEcg;

    /**
     * 发病时长，待定具体含义
     */
    private Integer diseaseDuration;

    /**
     * 知情同意时间
     */
    private Date informedConsentTime;

    /**
     * 离开急诊时间
     */
    private Date departureTime;

    /**
     * 出生日期
     */
    private Date birthday;

    /**
     * 病案号
     */
    private Integer medicalRecordNumber;

    /**
     * 家庭地址
     */
    private String homeAddress;

    /**
     * 患者本人手机号码
     */
    private String patientTelphone;

    /**
     * 医生姓名，待定具体含义
     */
    private String doctorName;

    /**
     * 到院时间，到哪个医院待定
     */
    private Date arriveHstptTime;

    /**
     * 到院时间是否估计，0表示否，1表示是
     */
    private Integer ifArriveHstptTimeEstimate;

    /**
     * 到院心源性休克(包括起病后院前)，0表示否，1表示是
     */
    private Integer arriveShock;

    /**
     * 到院心脏骤停(包括起病后院前)，0表示否，1表示是
     */
    private Integer arriveArrest;

    /**
     * 到院首次收缩压，待定具体含义
     */
    private Integer arriveFirstPressure;

    /**
     * 入院时间
     */
    private Date inHstptTime;

    /**
     * 出院时间
     */
    private Date outHstptTime;

    /**
     * 主要诊断，待定具体含义
     */
    private Integer mainDiagnosis;

    /**
     * 入院24小时内使用阿司匹林(包括起病后院前)，0表示否，1表示是
     */
    private Integer ifUsedAspirin;

    /**
     * 首次阿司匹林使用时间
     */
    private Date firstAspirinTime;

    /**
     * 入院24小时内使用P2Y12受体拮抗剂(包括起病后院前)，0表示否，1表示是
     */
    private Integer ifP2y12Used;

    /**
     * 入院24小时内使用B受体拮抗剂(包括起病后院前)，0表示否，1表示是
     */
    private Integer ifBetaUsed;

    /**
     * 院前再灌注治疗，0表示否，1表示是
     */
    private Integer beforeReperfusion;

    /**
     * 到院时再灌注治疗指征，1具备/2不具备(STEMI诊断不明确)/3不具备(胸痛缓解)/4不具备(ST段回落)/5不具备(其他原因)/6不具备(死亡)
     */
    private Integer beforeReperfusionTarget;

    /**
     * 院内实施再灌注治疗，待定具体含义
     */
    private Integer betweenReperfusion;

    /**
     * 直接PCI时间记录，1球囊扩张时间/2导丝通过时间/3血管穿刺时间/4手术开始时间
     */
    private Integer pciTimeRecorder;

    /**
     * 患者转运至有PCI能力医院，待定具体含义
     */
    private Integer transferToPci;

    /**
     * 启动转运时间
     */
    private Date transferStartTime;

    /**
     * 心脏超声评价LVEF(左室射血分数)检查，0表示否，1表示是
     */
    private Integer lvefCheck;

    /**
     * 首次心脏超声评价LVEF时间
     */
    private Date firstLvefTime;

    /**
     * 住院期间用药阿司匹林，待定具体含义
     */
    private Integer aspirinUsedDuringHstps;

    /**
     * 住院期间用药P2Y12受体拮抗剂，待定具体含义
     */
    private Integer p2y12UsedDuringHstpt;

    /**
     * 住院期间用药B受体拮抗剂，待定具体含义
     */
    private Integer betaUsedDuringHstpt;

    /**
     * 住院期间用药ACEI/ARB，待定具体含义
     */
    private Integer aaUsedDuringHstpt;

    /**
     * 住院期间用药他汀，待定具体含义
     */
    private Integer statinUsedDuringHstpt;

    /**
     * 出院带药阿司匹林，待定具体含义
     */
    private Integer medicationDischargeAspirin;

    /**
     * 出院带药P2Y12受体拮抗剂，待定具体含义
     */
    private Integer medicationDischargeP2y12;

    /**
     * 出院带药ACEI/ARB，待定具体含义
     */
    private Integer medicationDischargeAa;

    /**
     * 出院带药B受体拮抗剂，待定具体含义
     */
    private Integer medicationDischargeBeta;

    /**
     * 出院带药他汀，待定具体含义
     */
    private Integer medicationDischargeStatin;

    /**
     * 醛固酮受体拮抗剂适应证，待定具体含义
     */
    private Integer aldosteroneFitSymptom;

    /**
     * 出院带药醛固酮受体拮抗剂，待定具体含义
     */
    private Integer aldosteroneDischarge;

    /**
     * 出院健康教育，待定具体含义
     */
    private Integer outHstptEducation;

    /**
     * 出院后30天内非计划内全因再入院，待定具体含义
     */
    private Integer backAllcause;

    /**
     * 首诊30天内全因死亡，待定具体含义
     */
    private Integer firstDeadAllcause;

    /**
     * 首诊30天内心源性死亡，待定具体含义
     */
    private Integer firstCardiacAllcause;

    /**
     * 住院结局，待定具体含义
     */
    private Integer hstptOutcome;

    /**
     * 住院期间医疗费用，单位：元
     */
    private String hstptDurationCost;

    /**
     * 患者要去的医院是否在候选的医院里，0表示否，1表示是
     */
    private Integer ifAmongCandidates;

    /**
     * 患者要去的医院
     */
    private String aimedHstpt;

    /**
     * 最终患者选择的医院
     */
    private String arriveHstpt;

    /**
     * 候选医院
     */
    private String candidateHstpt;

    /**
     * 医院是否接受患者，0表示否，1表示是
     */
    private Integer ifAccept;

    /**
     * 想要去的医院的联系电话
     */
    private Integer candidateHstptTelnumber;

    /**
     * 想要去的医院的地址
     */
    private String candidateHstptLocation;

    /**
     * 转移担保人，身份证(家属或本人)
     */
    private String transferGuarantor;

    /**
     * 转移状态，待定具体含义
     */
    private Integer transferStatus;

    /**
     * 初步诊断，待定具体含义
     */
    private Integer primaryDiagnosis;

    /**
     * 首次抗血小板给药时间
     */
    private Date antiplateletAdministrationTime;

    /**
     * 阿司匹林剂量，单位：mg
     */
    private Integer aspirinDose;

    /**
     * 用药类型，待定具体含义
     */
    private Integer medicationType;

    /**
     * 用药剂量，单位：mg
     */
    private Integer medicationDose;

    /**
     * 溶栓核查，1直接PCI/2急诊仅造影/3择期PCI/4转运PCI/5无再灌注措施/6CABG/7仅药物治疗(收入院)
     */
    private Integer thrombolysisVerification;

    /**
     * 患者转归，待定具体含义
     */
    private Integer patientOutcome;

    /**
     * 出院诊断，待定具体含义
     */
    private Integer dischargeDiagnosis;

    /**
     * 住院天数，单位：天
     */
    private Integer hstptDays;

    /**
     * 总费用，单位：元
     */
    private Integer totalCost;

    /**
     * 心率，单位：次/分钟
     */
    private Integer heartRate;

    /**
     * 血压，格式：高压/低压 mmHg
     */
    private String bloodPressure;

    /**
     * 肌钙蛋白抽血时间
     */
    private Date troponinBloodDrawTime;

    /**
     * 肌钙蛋白报告时间
     */
    private Date troponinReportTime;

    /**
     * LDL-C检测，待定具体含义
     */
    private Integer ldlCheck;

    /**
     * cTNi数值，单位：ng/l
     */
    private Integer ctniNum;

    /**
     * cTNi结果，待定具体含义
     */
    private Integer ctniResult;

    /**
     * cTnT数值，单位：ng/l
     */
    private Integer ctntNum;

    /**
     * cTnT结果，待定具体含义
     */
    private Integer ctntResult;

    /**
     * ct，待定具体含义
     */
    private Integer ct;

    /**
     * 彩超，0表示否，1表示是
     */
    private Integer colorB;

    /**
     * 左室射血，0表示否，1表示是
     */
    private Integer leftEjection;

    /**
     * 
     */
    private Date createTime;

    /**
     * 
     */
    private Date modifyTime;

    /**
     * 
     */
    private Long createUsr;

    /**
     * 
     */
    private Long modifyUsr;

    /**
     * 
     */
    private Integer isdeleted;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;



    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        HealthRecords other = (HealthRecords) that;
        return (this.getPatientId() == null ? other.getPatientId() == null : this.getPatientId().equals(other.getPatientId()))
            && (this.getPatientNumber() == null ? other.getPatientNumber() == null : this.getPatientNumber().equals(other.getPatientNumber()))
            && (this.getPatientName() == null ? other.getPatientName() == null : this.getPatientName().equals(other.getPatientName()))
            && (this.getGender() == null ? other.getGender() == null : this.getGender().equals(other.getGender()))
            && (this.getAge() == null ? other.getAge() == null : this.getAge().equals(other.getAge()))
            && (this.getContact() == null ? other.getContact() == null : this.getContact().equals(other.getContact()))
            && (this.getTelephoneNumber() == null ? other.getTelephoneNumber() == null : this.getTelephoneNumber().equals(other.getTelephoneNumber()))
            && (this.getAdmissionNumber() == null ? other.getAdmissionNumber() == null : this.getAdmissionNumber().equals(other.getAdmissionNumber()))
            && (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getChestpainOrHeartattack() == null ? other.getChestpainOrHeartattack() == null : this.getChestpainOrHeartattack().equals(other.getChestpainOrHeartattack()))
            && (this.getDiseaseTime() == null ? other.getDiseaseTime() == null : this.getDiseaseTime().equals(other.getDiseaseTime()))
            && (this.getIfAccurate() == null ? other.getIfAccurate() == null : this.getIfAccurate().equals(other.getIfAccurate()))
            && (this.getIfHelp() == null ? other.getIfHelp() == null : this.getIfHelp().equals(other.getIfHelp()))
            && (this.getDiseaseAddress() == null ? other.getDiseaseAddress() == null : this.getDiseaseAddress().equals(other.getDiseaseAddress()))
            && (this.getSource() == null ? other.getSource() == null : this.getSource().equals(other.getSource()))
            && (this.getPatientAddress() == null ? other.getPatientAddress() == null : this.getPatientAddress().equals(other.getPatientAddress()))
            && (this.getFirstTreatTimeHstpt() == null ? other.getFirstTreatTimeHstpt() == null : this.getFirstTreatTimeHstpt().equals(other.getFirstTreatTimeHstpt()))
            && (this.getFirstEcgTimeHstpt() == null ? other.getFirstEcgTimeHstpt() == null : this.getFirstEcgTimeHstpt().equals(other.getFirstEcgTimeHstpt()))
            && (this.getFirstEcgPathHstpt() == null ? other.getFirstEcgPathHstpt() == null : this.getFirstEcgPathHstpt().equals(other.getFirstEcgPathHstpt()))
            && (this.getFirstEcgDefineTime() == null ? other.getFirstEcgDefineTime() == null : this.getFirstEcgDefineTime().equals(other.getFirstEcgDefineTime()))
            && (this.getRemoteEcg() == null ? other.getRemoteEcg() == null : this.getRemoteEcg().equals(other.getRemoteEcg()))
            && (this.getDiseaseDuration() == null ? other.getDiseaseDuration() == null : this.getDiseaseDuration().equals(other.getDiseaseDuration()))
            && (this.getInformedConsentTime() == null ? other.getInformedConsentTime() == null : this.getInformedConsentTime().equals(other.getInformedConsentTime()))
            && (this.getDepartureTime() == null ? other.getDepartureTime() == null : this.getDepartureTime().equals(other.getDepartureTime()))
            && (this.getBirthday() == null ? other.getBirthday() == null : this.getBirthday().equals(other.getBirthday()))
            && (this.getMedicalRecordNumber() == null ? other.getMedicalRecordNumber() == null : this.getMedicalRecordNumber().equals(other.getMedicalRecordNumber()))
            && (this.getHomeAddress() == null ? other.getHomeAddress() == null : this.getHomeAddress().equals(other.getHomeAddress()))
            && (this.getPatientTelphone() == null ? other.getPatientTelphone() == null : this.getPatientTelphone().equals(other.getPatientTelphone()))
            && (this.getDoctorName() == null ? other.getDoctorName() == null : this.getDoctorName().equals(other.getDoctorName()))
            && (this.getArriveHstptTime() == null ? other.getArriveHstptTime() == null : this.getArriveHstptTime().equals(other.getArriveHstptTime()))
            && (this.getIfArriveHstptTimeEstimate() == null ? other.getIfArriveHstptTimeEstimate() == null : this.getIfArriveHstptTimeEstimate().equals(other.getIfArriveHstptTimeEstimate()))
            && (this.getArriveShock() == null ? other.getArriveShock() == null : this.getArriveShock().equals(other.getArriveShock()))
            && (this.getArriveArrest() == null ? other.getArriveArrest() == null : this.getArriveArrest().equals(other.getArriveArrest()))
            && (this.getArriveFirstPressure() == null ? other.getArriveFirstPressure() == null : this.getArriveFirstPressure().equals(other.getArriveFirstPressure()))
            && (this.getInHstptTime() == null ? other.getInHstptTime() == null : this.getInHstptTime().equals(other.getInHstptTime()))
            && (this.getOutHstptTime() == null ? other.getOutHstptTime() == null : this.getOutHstptTime().equals(other.getOutHstptTime()))
            && (this.getMainDiagnosis() == null ? other.getMainDiagnosis() == null : this.getMainDiagnosis().equals(other.getMainDiagnosis()))
            && (this.getIfUsedAspirin() == null ? other.getIfUsedAspirin() == null : this.getIfUsedAspirin().equals(other.getIfUsedAspirin()))
            && (this.getFirstAspirinTime() == null ? other.getFirstAspirinTime() == null : this.getFirstAspirinTime().equals(other.getFirstAspirinTime()))
            && (this.getIfP2y12Used() == null ? other.getIfP2y12Used() == null : this.getIfP2y12Used().equals(other.getIfP2y12Used()))
            && (this.getIfBetaUsed() == null ? other.getIfBetaUsed() == null : this.getIfBetaUsed().equals(other.getIfBetaUsed()))
            && (this.getBeforeReperfusion() == null ? other.getBeforeReperfusion() == null : this.getBeforeReperfusion().equals(other.getBeforeReperfusion()))
            && (this.getBeforeReperfusionTarget() == null ? other.getBeforeReperfusionTarget() == null : this.getBeforeReperfusionTarget().equals(other.getBeforeReperfusionTarget()))
            && (this.getBetweenReperfusion() == null ? other.getBetweenReperfusion() == null : this.getBetweenReperfusion().equals(other.getBetweenReperfusion()))
            && (this.getPciTimeRecorder() == null ? other.getPciTimeRecorder() == null : this.getPciTimeRecorder().equals(other.getPciTimeRecorder()))
            && (this.getTransferToPci() == null ? other.getTransferToPci() == null : this.getTransferToPci().equals(other.getTransferToPci()))
            && (this.getTransferStartTime() == null ? other.getTransferStartTime() == null : this.getTransferStartTime().equals(other.getTransferStartTime()))
            && (this.getLvefCheck() == null ? other.getLvefCheck() == null : this.getLvefCheck().equals(other.getLvefCheck()))
            && (this.getFirstLvefTime() == null ? other.getFirstLvefTime() == null : this.getFirstLvefTime().equals(other.getFirstLvefTime()))
            && (this.getAspirinUsedDuringHstps() == null ? other.getAspirinUsedDuringHstps() == null : this.getAspirinUsedDuringHstps().equals(other.getAspirinUsedDuringHstps()))
            && (this.getP2y12UsedDuringHstpt() == null ? other.getP2y12UsedDuringHstpt() == null : this.getP2y12UsedDuringHstpt().equals(other.getP2y12UsedDuringHstpt()))
            && (this.getBetaUsedDuringHstpt() == null ? other.getBetaUsedDuringHstpt() == null : this.getBetaUsedDuringHstpt().equals(other.getBetaUsedDuringHstpt()))
            && (this.getAaUsedDuringHstpt() == null ? other.getAaUsedDuringHstpt() == null : this.getAaUsedDuringHstpt().equals(other.getAaUsedDuringHstpt()))
            && (this.getStatinUsedDuringHstpt() == null ? other.getStatinUsedDuringHstpt() == null : this.getStatinUsedDuringHstpt().equals(other.getStatinUsedDuringHstpt()))
            && (this.getMedicationDischargeAspirin() == null ? other.getMedicationDischargeAspirin() == null : this.getMedicationDischargeAspirin().equals(other.getMedicationDischargeAspirin()))
            && (this.getMedicationDischargeP2y12() == null ? other.getMedicationDischargeP2y12() == null : this.getMedicationDischargeP2y12().equals(other.getMedicationDischargeP2y12()))
            && (this.getMedicationDischargeAa() == null ? other.getMedicationDischargeAa() == null : this.getMedicationDischargeAa().equals(other.getMedicationDischargeAa()))
            && (this.getMedicationDischargeBeta() == null ? other.getMedicationDischargeBeta() == null : this.getMedicationDischargeBeta().equals(other.getMedicationDischargeBeta()))
            && (this.getMedicationDischargeStatin() == null ? other.getMedicationDischargeStatin() == null : this.getMedicationDischargeStatin().equals(other.getMedicationDischargeStatin()))
            && (this.getAldosteroneFitSymptom() == null ? other.getAldosteroneFitSymptom() == null : this.getAldosteroneFitSymptom().equals(other.getAldosteroneFitSymptom()))
            && (this.getAldosteroneDischarge() == null ? other.getAldosteroneDischarge() == null : this.getAldosteroneDischarge().equals(other.getAldosteroneDischarge()))
            && (this.getOutHstptEducation() == null ? other.getOutHstptEducation() == null : this.getOutHstptEducation().equals(other.getOutHstptEducation()))
            && (this.getBackAllcause() == null ? other.getBackAllcause() == null : this.getBackAllcause().equals(other.getBackAllcause()))
            && (this.getFirstDeadAllcause() == null ? other.getFirstDeadAllcause() == null : this.getFirstDeadAllcause().equals(other.getFirstDeadAllcause()))
            && (this.getFirstCardiacAllcause() == null ? other.getFirstCardiacAllcause() == null : this.getFirstCardiacAllcause().equals(other.getFirstCardiacAllcause()))
            && (this.getHstptOutcome() == null ? other.getHstptOutcome() == null : this.getHstptOutcome().equals(other.getHstptOutcome()))
            && (this.getHstptDurationCost() == null ? other.getHstptDurationCost() == null : this.getHstptDurationCost().equals(other.getHstptDurationCost()))
            && (this.getIfAmongCandidates() == null ? other.getIfAmongCandidates() == null : this.getIfAmongCandidates().equals(other.getIfAmongCandidates()))
            && (this.getAimedHstpt() == null ? other.getAimedHstpt() == null : this.getAimedHstpt().equals(other.getAimedHstpt()))
            && (this.getArriveHstpt() == null ? other.getArriveHstpt() == null : this.getArriveHstpt().equals(other.getArriveHstpt()))
            && (this.getCandidateHstpt() == null ? other.getCandidateHstpt() == null : this.getCandidateHstpt().equals(other.getCandidateHstpt()))
            && (this.getIfAccept() == null ? other.getIfAccept() == null : this.getIfAccept().equals(other.getIfAccept()))
            && (this.getCandidateHstptTelnumber() == null ? other.getCandidateHstptTelnumber() == null : this.getCandidateHstptTelnumber().equals(other.getCandidateHstptTelnumber()))
            && (this.getCandidateHstptLocation() == null ? other.getCandidateHstptLocation() == null : this.getCandidateHstptLocation().equals(other.getCandidateHstptLocation()))
            && (this.getTransferGuarantor() == null ? other.getTransferGuarantor() == null : this.getTransferGuarantor().equals(other.getTransferGuarantor()))
            && (this.getTransferStatus() == null ? other.getTransferStatus() == null : this.getTransferStatus().equals(other.getTransferStatus()))
            && (this.getPrimaryDiagnosis() == null ? other.getPrimaryDiagnosis() == null : this.getPrimaryDiagnosis().equals(other.getPrimaryDiagnosis()))
            && (this.getAntiplateletAdministrationTime() == null ? other.getAntiplateletAdministrationTime() == null : this.getAntiplateletAdministrationTime().equals(other.getAntiplateletAdministrationTime()))
            && (this.getAspirinDose() == null ? other.getAspirinDose() == null : this.getAspirinDose().equals(other.getAspirinDose()))
            && (this.getMedicationType() == null ? other.getMedicationType() == null : this.getMedicationType().equals(other.getMedicationType()))
            && (this.getMedicationDose() == null ? other.getMedicationDose() == null : this.getMedicationDose().equals(other.getMedicationDose()))
            && (this.getThrombolysisVerification() == null ? other.getThrombolysisVerification() == null : this.getThrombolysisVerification().equals(other.getThrombolysisVerification()))
            && (this.getPatientOutcome() == null ? other.getPatientOutcome() == null : this.getPatientOutcome().equals(other.getPatientOutcome()))
            && (this.getDischargeDiagnosis() == null ? other.getDischargeDiagnosis() == null : this.getDischargeDiagnosis().equals(other.getDischargeDiagnosis()))
            && (this.getHstptDays() == null ? other.getHstptDays() == null : this.getHstptDays().equals(other.getHstptDays()))
            && (this.getTotalCost() == null ? other.getTotalCost() == null : this.getTotalCost().equals(other.getTotalCost()))
            && (this.getHeartRate() == null ? other.getHeartRate() == null : this.getHeartRate().equals(other.getHeartRate()))
            && (this.getBloodPressure() == null ? other.getBloodPressure() == null : this.getBloodPressure().equals(other.getBloodPressure()))
            && (this.getTroponinBloodDrawTime() == null ? other.getTroponinBloodDrawTime() == null : this.getTroponinBloodDrawTime().equals(other.getTroponinBloodDrawTime()))
            && (this.getTroponinReportTime() == null ? other.getTroponinReportTime() == null : this.getTroponinReportTime().equals(other.getTroponinReportTime()))
            && (this.getLdlCheck() == null ? other.getLdlCheck() == null : this.getLdlCheck().equals(other.getLdlCheck()))
            && (this.getCtniNum() == null ? other.getCtniNum() == null : this.getCtniNum().equals(other.getCtniNum()))
            && (this.getCtniResult() == null ? other.getCtniResult() == null : this.getCtniResult().equals(other.getCtniResult()))
            && (this.getCtntNum() == null ? other.getCtntNum() == null : this.getCtntNum().equals(other.getCtntNum()))
            && (this.getCtntResult() == null ? other.getCtntResult() == null : this.getCtntResult().equals(other.getCtntResult()))
            && (this.getCt() == null ? other.getCt() == null : this.getCt().equals(other.getCt()))
            && (this.getColorB() == null ? other.getColorB() == null : this.getColorB().equals(other.getColorB()))
            && (this.getLeftEjection() == null ? other.getLeftEjection() == null : this.getLeftEjection().equals(other.getLeftEjection()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getModifyTime() == null ? other.getModifyTime() == null : this.getModifyTime().equals(other.getModifyTime()))
            && (this.getCreateUsr() == null ? other.getCreateUsr() == null : this.getCreateUsr().equals(other.getCreateUsr()))
            && (this.getModifyUsr() == null ? other.getModifyUsr() == null : this.getModifyUsr().equals(other.getModifyUsr()))
            && (this.getIsdeleted() == null ? other.getIsdeleted() == null : this.getIsdeleted().equals(other.getIsdeleted()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getPatientId() == null) ? 0 : getPatientId().hashCode());
        result = prime * result + ((getPatientNumber() == null) ? 0 : getPatientNumber().hashCode());
        result = prime * result + ((getPatientName() == null) ? 0 : getPatientName().hashCode());
        result = prime * result + ((getGender() == null) ? 0 : getGender().hashCode());
        result = prime * result + ((getAge() == null) ? 0 : getAge().hashCode());
        result = prime * result + ((getContact() == null) ? 0 : getContact().hashCode());
        result = prime * result + ((getTelephoneNumber() == null) ? 0 : getTelephoneNumber().hashCode());
        result = prime * result + ((getAdmissionNumber() == null) ? 0 : getAdmissionNumber().hashCode());
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getChestpainOrHeartattack() == null) ? 0 : getChestpainOrHeartattack().hashCode());
        result = prime * result + ((getDiseaseTime() == null) ? 0 : getDiseaseTime().hashCode());
        result = prime * result + ((getIfAccurate() == null) ? 0 : getIfAccurate().hashCode());
        result = prime * result + ((getIfHelp() == null) ? 0 : getIfHelp().hashCode());
        result = prime * result + ((getDiseaseAddress() == null) ? 0 : getDiseaseAddress().hashCode());
        result = prime * result + ((getSource() == null) ? 0 : getSource().hashCode());
        result = prime * result + ((getPatientAddress() == null) ? 0 : getPatientAddress().hashCode());
        result = prime * result + ((getFirstTreatTimeHstpt() == null) ? 0 : getFirstTreatTimeHstpt().hashCode());
        result = prime * result + ((getFirstEcgTimeHstpt() == null) ? 0 : getFirstEcgTimeHstpt().hashCode());
        result = prime * result + ((getFirstEcgPathHstpt() == null) ? 0 : getFirstEcgPathHstpt().hashCode());
        result = prime * result + ((getFirstEcgDefineTime() == null) ? 0 : getFirstEcgDefineTime().hashCode());
        result = prime * result + ((getRemoteEcg() == null) ? 0 : getRemoteEcg().hashCode());
        result = prime * result + ((getDiseaseDuration() == null) ? 0 : getDiseaseDuration().hashCode());
        result = prime * result + ((getInformedConsentTime() == null) ? 0 : getInformedConsentTime().hashCode());
        result = prime * result + ((getDepartureTime() == null) ? 0 : getDepartureTime().hashCode());
        result = prime * result + ((getBirthday() == null) ? 0 : getBirthday().hashCode());
        result = prime * result + ((getMedicalRecordNumber() == null) ? 0 : getMedicalRecordNumber().hashCode());
        result = prime * result + ((getHomeAddress() == null) ? 0 : getHomeAddress().hashCode());
        result = prime * result + ((getPatientTelphone() == null) ? 0 : getPatientTelphone().hashCode());
        result = prime * result + ((getDoctorName() == null) ? 0 : getDoctorName().hashCode());
        result = prime * result + ((getArriveHstptTime() == null) ? 0 : getArriveHstptTime().hashCode());
        result = prime * result + ((getIfArriveHstptTimeEstimate() == null) ? 0 : getIfArriveHstptTimeEstimate().hashCode());
        result = prime * result + ((getArriveShock() == null) ? 0 : getArriveShock().hashCode());
        result = prime * result + ((getArriveArrest() == null) ? 0 : getArriveArrest().hashCode());
        result = prime * result + ((getArriveFirstPressure() == null) ? 0 : getArriveFirstPressure().hashCode());
        result = prime * result + ((getInHstptTime() == null) ? 0 : getInHstptTime().hashCode());
        result = prime * result + ((getOutHstptTime() == null) ? 0 : getOutHstptTime().hashCode());
        result = prime * result + ((getMainDiagnosis() == null) ? 0 : getMainDiagnosis().hashCode());
        result = prime * result + ((getIfUsedAspirin() == null) ? 0 : getIfUsedAspirin().hashCode());
        result = prime * result + ((getFirstAspirinTime() == null) ? 0 : getFirstAspirinTime().hashCode());
        result = prime * result + ((getIfP2y12Used() == null) ? 0 : getIfP2y12Used().hashCode());
        result = prime * result + ((getIfBetaUsed() == null) ? 0 : getIfBetaUsed().hashCode());
        result = prime * result + ((getBeforeReperfusion() == null) ? 0 : getBeforeReperfusion().hashCode());
        result = prime * result + ((getBeforeReperfusionTarget() == null) ? 0 : getBeforeReperfusionTarget().hashCode());
        result = prime * result + ((getBetweenReperfusion() == null) ? 0 : getBetweenReperfusion().hashCode());
        result = prime * result + ((getPciTimeRecorder() == null) ? 0 : getPciTimeRecorder().hashCode());
        result = prime * result + ((getTransferToPci() == null) ? 0 : getTransferToPci().hashCode());
        result = prime * result + ((getTransferStartTime() == null) ? 0 : getTransferStartTime().hashCode());
        result = prime * result + ((getLvefCheck() == null) ? 0 : getLvefCheck().hashCode());
        result = prime * result + ((getFirstLvefTime() == null) ? 0 : getFirstLvefTime().hashCode());
        result = prime * result + ((getAspirinUsedDuringHstps() == null) ? 0 : getAspirinUsedDuringHstps().hashCode());
        result = prime * result + ((getP2y12UsedDuringHstpt() == null) ? 0 : getP2y12UsedDuringHstpt().hashCode());
        result = prime * result + ((getBetaUsedDuringHstpt() == null) ? 0 : getBetaUsedDuringHstpt().hashCode());
        result = prime * result + ((getAaUsedDuringHstpt() == null) ? 0 : getAaUsedDuringHstpt().hashCode());
        result = prime * result + ((getStatinUsedDuringHstpt() == null) ? 0 : getStatinUsedDuringHstpt().hashCode());
        result = prime * result + ((getMedicationDischargeAspirin() == null) ? 0 : getMedicationDischargeAspirin().hashCode());
        result = prime * result + ((getMedicationDischargeP2y12() == null) ? 0 : getMedicationDischargeP2y12().hashCode());
        result = prime * result + ((getMedicationDischargeAa() == null) ? 0 : getMedicationDischargeAa().hashCode());
        result = prime * result + ((getMedicationDischargeBeta() == null) ? 0 : getMedicationDischargeBeta().hashCode());
        result = prime * result + ((getMedicationDischargeStatin() == null) ? 0 : getMedicationDischargeStatin().hashCode());
        result = prime * result + ((getAldosteroneFitSymptom() == null) ? 0 : getAldosteroneFitSymptom().hashCode());
        result = prime * result + ((getAldosteroneDischarge() == null) ? 0 : getAldosteroneDischarge().hashCode());
        result = prime * result + ((getOutHstptEducation() == null) ? 0 : getOutHstptEducation().hashCode());
        result = prime * result + ((getBackAllcause() == null) ? 0 : getBackAllcause().hashCode());
        result = prime * result + ((getFirstDeadAllcause() == null) ? 0 : getFirstDeadAllcause().hashCode());
        result = prime * result + ((getFirstCardiacAllcause() == null) ? 0 : getFirstCardiacAllcause().hashCode());
        result = prime * result + ((getHstptOutcome() == null) ? 0 : getHstptOutcome().hashCode());
        result = prime * result + ((getHstptDurationCost() == null) ? 0 : getHstptDurationCost().hashCode());
        result = prime * result + ((getIfAmongCandidates() == null) ? 0 : getIfAmongCandidates().hashCode());
        result = prime * result + ((getAimedHstpt() == null) ? 0 : getAimedHstpt().hashCode());
        result = prime * result + ((getArriveHstpt() == null) ? 0 : getArriveHstpt().hashCode());
        result = prime * result + ((getCandidateHstpt() == null) ? 0 : getCandidateHstpt().hashCode());
        result = prime * result + ((getIfAccept() == null) ? 0 : getIfAccept().hashCode());
        result = prime * result + ((getCandidateHstptTelnumber() == null) ? 0 : getCandidateHstptTelnumber().hashCode());
        result = prime * result + ((getCandidateHstptLocation() == null) ? 0 : getCandidateHstptLocation().hashCode());
        result = prime * result + ((getTransferGuarantor() == null) ? 0 : getTransferGuarantor().hashCode());
        result = prime * result + ((getTransferStatus() == null) ? 0 : getTransferStatus().hashCode());
        result = prime * result + ((getPrimaryDiagnosis() == null) ? 0 : getPrimaryDiagnosis().hashCode());
        result = prime * result + ((getAntiplateletAdministrationTime() == null) ? 0 : getAntiplateletAdministrationTime().hashCode());
        result = prime * result + ((getAspirinDose() == null) ? 0 : getAspirinDose().hashCode());
        result = prime * result + ((getMedicationType() == null) ? 0 : getMedicationType().hashCode());
        result = prime * result + ((getMedicationDose() == null) ? 0 : getMedicationDose().hashCode());
        result = prime * result + ((getThrombolysisVerification() == null) ? 0 : getThrombolysisVerification().hashCode());
        result = prime * result + ((getPatientOutcome() == null) ? 0 : getPatientOutcome().hashCode());
        result = prime * result + ((getDischargeDiagnosis() == null) ? 0 : getDischargeDiagnosis().hashCode());
        result = prime * result + ((getHstptDays() == null) ? 0 : getHstptDays().hashCode());
        result = prime * result + ((getTotalCost() == null) ? 0 : getTotalCost().hashCode());
        result = prime * result + ((getHeartRate() == null) ? 0 : getHeartRate().hashCode());
        result = prime * result + ((getBloodPressure() == null) ? 0 : getBloodPressure().hashCode());
        result = prime * result + ((getTroponinBloodDrawTime() == null) ? 0 : getTroponinBloodDrawTime().hashCode());
        result = prime * result + ((getTroponinReportTime() == null) ? 0 : getTroponinReportTime().hashCode());
        result = prime * result + ((getLdlCheck() == null) ? 0 : getLdlCheck().hashCode());
        result = prime * result + ((getCtniNum() == null) ? 0 : getCtniNum().hashCode());
        result = prime * result + ((getCtniResult() == null) ? 0 : getCtniResult().hashCode());
        result = prime * result + ((getCtntNum() == null) ? 0 : getCtntNum().hashCode());
        result = prime * result + ((getCtntResult() == null) ? 0 : getCtntResult().hashCode());
        result = prime * result + ((getCt() == null) ? 0 : getCt().hashCode());
        result = prime * result + ((getColorB() == null) ? 0 : getColorB().hashCode());
        result = prime * result + ((getLeftEjection() == null) ? 0 : getLeftEjection().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getModifyTime() == null) ? 0 : getModifyTime().hashCode());
        result = prime * result + ((getCreateUsr() == null) ? 0 : getCreateUsr().hashCode());
        result = prime * result + ((getModifyUsr() == null) ? 0 : getModifyUsr().hashCode());
        result = prime * result + ((getIsdeleted() == null) ? 0 : getIsdeleted().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", patientId=").append(patientId);
        sb.append(", patientNumber=").append(patientNumber);
        sb.append(", patientName=").append(patientName);
        sb.append(", gender=").append(gender);
        sb.append(", age=").append(age);
        sb.append(", contact=").append(contact);
        sb.append(", telephoneNumber=").append(telephoneNumber);
        sb.append(", admissionNumber=").append(admissionNumber);
        sb.append(", id=").append(id);
        sb.append(", chestpainOrHeartattack=").append(chestpainOrHeartattack);
        sb.append(", diseaseTime=").append(diseaseTime);
        sb.append(", ifAccurate=").append(ifAccurate);
        sb.append(", ifHelp=").append(ifHelp);
        sb.append(", diseaseAddress=").append(diseaseAddress);
        sb.append(", source=").append(source);
        sb.append(", patientAddress=").append(patientAddress);
        sb.append(", firstTreatTimeHstpt=").append(firstTreatTimeHstpt);
        sb.append(", firstEcgTimeHstpt=").append(firstEcgTimeHstpt);
        sb.append(", firstEcgPathHstpt=").append(firstEcgPathHstpt);
        sb.append(", firstEcgDefineTime=").append(firstEcgDefineTime);
        sb.append(", remoteEcg=").append(remoteEcg);
        sb.append(", diseaseDuration=").append(diseaseDuration);
        sb.append(", informedConsentTime=").append(informedConsentTime);
        sb.append(", departureTime=").append(departureTime);
        sb.append(", birthday=").append(birthday);
        sb.append(", medicalRecordNumber=").append(medicalRecordNumber);
        sb.append(", homeAddress=").append(homeAddress);
        sb.append(", patientTelphone=").append(patientTelphone);
        sb.append(", doctorName=").append(doctorName);
        sb.append(", arriveHstptTime=").append(arriveHstptTime);
        sb.append(", ifArriveHstptTimeEstimate=").append(ifArriveHstptTimeEstimate);
        sb.append(", arriveShock=").append(arriveShock);
        sb.append(", arriveArrest=").append(arriveArrest);
        sb.append(", arriveFirstPressure=").append(arriveFirstPressure);
        sb.append(", inHstptTime=").append(inHstptTime);
        sb.append(", outHstptTime=").append(outHstptTime);
        sb.append(", mainDiagnosis=").append(mainDiagnosis);
        sb.append(", ifUsedAspirin=").append(ifUsedAspirin);
        sb.append(", firstAspirinTime=").append(firstAspirinTime);
        sb.append(", ifP2y12Used=").append(ifP2y12Used);
        sb.append(", ifBetaUsed=").append(ifBetaUsed);
        sb.append(", beforeReperfusion=").append(beforeReperfusion);
        sb.append(", beforeReperfusionTarget=").append(beforeReperfusionTarget);
        sb.append(", betweenReperfusion=").append(betweenReperfusion);
        sb.append(", pciTimeRecorder=").append(pciTimeRecorder);
        sb.append(", transferToPci=").append(transferToPci);
        sb.append(", transferStartTime=").append(transferStartTime);
        sb.append(", lvefCheck=").append(lvefCheck);
        sb.append(", firstLvefTime=").append(firstLvefTime);
        sb.append(", aspirinUsedDuringHstps=").append(aspirinUsedDuringHstps);
        sb.append(", p2y12UsedDuringHstpt=").append(p2y12UsedDuringHstpt);
        sb.append(", betaUsedDuringHstpt=").append(betaUsedDuringHstpt);
        sb.append(", aaUsedDuringHstpt=").append(aaUsedDuringHstpt);
        sb.append(", statinUsedDuringHstpt=").append(statinUsedDuringHstpt);
        sb.append(", medicationDischargeAspirin=").append(medicationDischargeAspirin);
        sb.append(", medicationDischargeP2y12=").append(medicationDischargeP2y12);
        sb.append(", medicationDischargeAa=").append(medicationDischargeAa);
        sb.append(", medicationDischargeBeta=").append(medicationDischargeBeta);
        sb.append(", medicationDischargeStatin=").append(medicationDischargeStatin);
        sb.append(", aldosteroneFitSymptom=").append(aldosteroneFitSymptom);
        sb.append(", aldosteroneDischarge=").append(aldosteroneDischarge);
        sb.append(", outHstptEducation=").append(outHstptEducation);
        sb.append(", backAllcause=").append(backAllcause);
        sb.append(", firstDeadAllcause=").append(firstDeadAllcause);
        sb.append(", firstCardiacAllcause=").append(firstCardiacAllcause);
        sb.append(", hstptOutcome=").append(hstptOutcome);
        sb.append(", hstptDurationCost=").append(hstptDurationCost);
        sb.append(", ifAmongCandidates=").append(ifAmongCandidates);
        sb.append(", aimedHstpt=").append(aimedHstpt);
        sb.append(", arriveHstpt=").append(arriveHstpt);
        sb.append(", candidateHstpt=").append(candidateHstpt);
        sb.append(", ifAccept=").append(ifAccept);
        sb.append(", candidateHstptTelnumber=").append(candidateHstptTelnumber);
        sb.append(", candidateHstptLocation=").append(candidateHstptLocation);
        sb.append(", transferGuarantor=").append(transferGuarantor);
        sb.append(", transferStatus=").append(transferStatus);
        sb.append(", primaryDiagnosis=").append(primaryDiagnosis);
        sb.append(", antiplateletAdministrationTime=").append(antiplateletAdministrationTime);
        sb.append(", aspirinDose=").append(aspirinDose);
        sb.append(", medicationType=").append(medicationType);
        sb.append(", medicationDose=").append(medicationDose);
        sb.append(", thrombolysisVerification=").append(thrombolysisVerification);
        sb.append(", patientOutcome=").append(patientOutcome);
        sb.append(", dischargeDiagnosis=").append(dischargeDiagnosis);
        sb.append(", hstptDays=").append(hstptDays);
        sb.append(", totalCost=").append(totalCost);
        sb.append(", heartRate=").append(heartRate);
        sb.append(", bloodPressure=").append(bloodPressure);
        sb.append(", troponinBloodDrawTime=").append(troponinBloodDrawTime);
        sb.append(", troponinReportTime=").append(troponinReportTime);
        sb.append(", ldlCheck=").append(ldlCheck);
        sb.append(", ctniNum=").append(ctniNum);
        sb.append(", ctniResult=").append(ctniResult);
        sb.append(", ctntNum=").append(ctntNum);
        sb.append(", ctntResult=").append(ctntResult);
        sb.append(", ct=").append(ct);
        sb.append(", colorB=").append(colorB);
        sb.append(", leftEjection=").append(leftEjection);
        sb.append(", createTime=").append(createTime);
        sb.append(", modifyTime=").append(modifyTime);
        sb.append(", createUsr=").append(createUsr);
        sb.append(", modifyUsr=").append(modifyUsr);
        sb.append(", isdeleted=").append(isdeleted);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}