package com.qll.chaindemo.mapper;

import com.qll.chaindemo.domain.DoctorInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
* @author 86182
* @description 针对表【doctor_info(主治医师信息表)】的数据库操作Mapper
* @createDate 2024-10-24 21:33:09
* @Entity generator.domain.DoctorInfo
*/
@Mapper
public interface DoctorInfoMapper extends BaseMapper<DoctorInfo> {

}




