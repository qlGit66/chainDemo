package com.qll.chaindemo.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.qll.chaindemo.domain.AmbulancesInfo;
import com.qll.chaindemo.service.AmbulancesInfoService;
import com.qll.chaindemo.mapper.AmbulancesInfoMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

/**
* @author 86182
* @description 针对表【ambulances_info(救护车信息表)】的数据库操作Service实现
* @createDate 2024-10-24 21:33:30
*/
@Service
public class AmbulancesInfoServiceImpl implements AmbulancesInfoService{
    @Resource
    private  AmbulancesInfoMapper ambulancesInfoMapper;
    @Override
    public AmbulancesInfo findLeisureAmbulance() {
       return null;
    }
}




