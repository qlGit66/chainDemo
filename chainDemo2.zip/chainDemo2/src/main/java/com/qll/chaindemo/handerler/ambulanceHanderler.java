package com.qll.chaindemo.handerler;

import com.qll.chaindemo.common.classes.ChainData;
import com.qll.chaindemo.domain.AmbulancesInfo;
import com.qll.chaindemo.domain.NodeChainLog;
import com.qll.chaindemo.interfaces.HospitalHandler;
import com.qll.chaindemo.service.DoctorInfoService;
import com.qll.chaindemo.service.NodeChainLogService;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * @author 86182
 */
@Slf4j
@Component
@Scope("prototype")
public class ambulanceHanderler  implements HospitalHandler {

    private HospitalHandler nextHandler;

    private ChainData request;

    @Resource
    private NodeChainLogService nodeChainLogService;
    @Resource
    private DoctorInfoService doctorInfoService;
    @Resource
    private pciHanderler pciHanderler;
    @Override
    public void setNextHandler(HospitalHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public AmbulancesInfo handleRequest(ChainData request) {
        //救护车节点完成
        log.info("救护车节点正在赶PCI");

        this.nextHandler = pciHanderler;
        log.info("节点转移到PCI，等待救护车彻底将患者交给PCI");
        log.info("患者到PCI医院");
        log.info("主治医生通知值班人员就位");
        doctorInfoService.reform(request);
        log.info("主治医师引导120");
        doctorInfoService.guideAmbulance(request);
        //120已经将人送往医院
        NodeChainLog nodeChainLog = NodeChainLog.builder().id(request.getNodeId())
                .status(1).endTime(LocalDateTime.now())
                .modifyTime(LocalDateTime.now()).build();
        nodeChainLogService.addNodeChainLog(nodeChainLog);
        request.setNodeId(null);
        log.info("救护车节点彻底ok，节点到PCI");
        pciHanderler.handleRequest(request);
        return null;
    }

}
