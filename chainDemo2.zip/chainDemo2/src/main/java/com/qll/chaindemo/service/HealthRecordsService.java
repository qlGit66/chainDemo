package com.qll.chaindemo.service;

import com.qll.chaindemo.domain.HealthRecords;

/**
* @author 86182
* @description 针对表【health_records(存储患者基本信息的表格)】的数据库操作Service
* @createDate 2024-10-24 21:40:52
*/
public interface HealthRecordsService {

    void updateRecords(HealthRecords healthRecords);

    void addHealthRecords(HealthRecords healthRecords);
}

