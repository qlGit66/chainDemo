package com.qll.chaindemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChainDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
